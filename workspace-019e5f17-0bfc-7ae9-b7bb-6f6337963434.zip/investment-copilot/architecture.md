# AI-Native Investment Copilot — Core Architecture

## System Overview

An AI-native investment copilot that uses external LLM APIs (OpenAI/Claude/Gemini) as its reasoning core,
augmented by structured memory, dynamic context injection, portfolio analysis, a recommendation engine,
and a proactive alert system.

---

## 1. AI Reasoning System
## 2. Memory Architecture
## 3. Context Injection System
## 4. Portfolio Analysis Logic
## 5. Recommendation Engine
## 6. Proactive Alert System
