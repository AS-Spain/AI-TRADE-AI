# InvestIQ Copilot — Production MVP

AI-native investment copilot. FastAPI backend + Next.js 14 frontend.
Runs with Docker Compose in 3 commands.

---

## Stack

| Layer | Technology |
|---|---|
| Backend | FastAPI (Python 3.12) + uvicorn |
| Database | PostgreSQL 16 + pgvector extension |
| Cache / STM | Redis 7 |
| AI | OpenAI GPT-4o (primary) / Anthropic Claude (fallback) |
| Embeddings | OpenAI text-embedding-3-small (1536-dim) |
| Vector store | pgvector (built into Postgres) |
| Market data | Polygon.io (mock fallback if no key) |
| Frontend | Next.js 14, TailwindCSS, Recharts, Zustand, TanStack Query |
| Auth | JWT (jose) + bcrypt |

---

## Quick Start

### 1. Prerequisites
- Docker + Docker Compose
- An OpenAI API key (recommended) — or use demo mode

### 2. Configure
```bash
cd investment-copilot/mvp/backend
cp .env.example .env
# Edit .env — add at minimum your OPENAI_API_KEY
```

### 3. Launch
```bash
cd investment-copilot/mvp/infra
docker-compose up --build
```

| Service | URL |
|---|---|
| Frontend | http://localhost:3000 |
| Backend API | http://localhost:8000 |
| API Docs | http://localhost:8000/api/docs |

### 4. First Run
1. Open http://localhost:3000
2. Click **Sign up** — create an account
3. Go to **Portfolio** → Add positions (e.g. AAPL, MSFT, NVDA)
4. Return to **Dashboard** to see live prices and analytics
5. Click **AI Copilot** and start asking questions

---

## Development (without Docker)

### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in values

# Start Postgres + Redis (Docker only for infra)
docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=postgres pgvector/pgvector:pg16
docker run -d -p 6379:6379 redis:7-alpine

uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
echo "NEXT_PUBLIC_API_URL=http://localhost:8000" > .env.local
npm run dev
```

---

## API Reference (key endpoints)

```
POST   /api/v1/auth/register        Register user
POST   /api/v1/auth/login           Login
GET    /api/v1/auth/me              Current user
PATCH  /api/v1/auth/me/profile      Update investor profile

GET    /api/v1/dashboard            Full dashboard payload

GET    /api/v1/portfolio            Portfolio with live prices
POST   /api/v1/portfolio/holdings   Add position
DELETE /api/v1/portfolio/holdings/{id}

POST   /api/v1/chat                 AI chat (JSON response)
POST   /api/v1/chat/stream          AI chat (SSE streaming)
GET    /api/v1/chat/history/{session_id}
POST   /api/v1/chat/session/{id}/end   Trigger memory ingestion

GET    /api/v1/alerts               List alerts
PATCH  /api/v1/alerts/{id}/read
PATCH  /api/v1/alerts/read-all

GET    /api/v1/market/quote/{ticker}
GET    /api/v1/market/macro
```

---

## Architecture Decisions

### AI Memory
- **Short-term**: Redis list per `session_id`, 50-message cap, 2h TTL
- **Long-term**: pgvector embeddings (1536-dim), cosine similarity recall
- **Ingestion**: Background task at session end — LLM extracts insights, embeds, stores

### Context Injection
Each chat message injects up to 6 context slots:
1. Portfolio state (live-priced holdings, P&L, weights)
2. Conversation history (last 8 turns)
3. Long-term memory recall (top-4 semantic matches)
4. Live market quotes (all held tickers)
5. Recent news (held tickers, last 24h)
6. Macro snapshot (rates, VIX, CPI)

### Streaming
Chat supports SSE streaming via `POST /api/v1/chat/stream`.
The frontend uses the Fetch API + ReadableStream for real-time token delivery.

### Demo Mode
If no AI API keys are configured, the app runs in **demo mode**:
- Portfolio, auth, market data (mocked) all work
- Chat returns a structured fallback response explaining what would happen
- No AI features are silently broken

---

## Production Checklist

- [ ] Change `SECRET_KEY` in `.env`
- [ ] Set strong Postgres password
- [ ] Configure `ALLOWED_ORIGINS` for your domain
- [ ] Add Polygon.io key for real market data
- [ ] Set up HTTPS (nginx reverse proxy)
- [ ] Configure Redis persistence / eviction policy
- [ ] Add Sentry for error tracking
- [ ] Set up log aggregation (Datadog / CloudWatch)
- [ ] Add rate limiting (nginx or FastAPI middleware)
- [ ] Enable pgvector IVFFlat index for >100k memory chunks
