"""
Central settings — all values come from environment variables / .env file.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ── App ───────────────────────────────────────────────────────────
    APP_NAME: str = "InvestIQ Copilot"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = False
    SECRET_KEY: str = "change-me-in-production-please"
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000"]

    # ── Database ──────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/investiq"
    REDIS_URL: str = "redis://localhost:6379/0"

    # ── AI Providers ──────────────────────────────────────────────────
    OPENAI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""
    GEMINI_API_KEY: str = ""

    # Default LLM to use for chat (openai | anthropic | gemini)
    PRIMARY_LLM_PROVIDER: str = "openai"
    PRIMARY_LLM_MODEL: str = "gpt-4o"
    EMBEDDING_MODEL: str = "text-embedding-3-small"

    # ── Market Data ───────────────────────────────────────────────────
    POLYGON_API_KEY: str = ""          # polygon.io — real-time quotes & news
    ALPHA_VANTAGE_KEY: str = ""        # fallback

    # ── Auth ──────────────────────────────────────────────────────────
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24   # 24 h

    # ── Vector Store ──────────────────────────────────────────────────
    VECTOR_DIMENSIONS: int = 1536        # text-embedding-3-small

    # ── Alert / Scheduler ────────────────────────────────────────────
    PRICE_ALERT_THRESHOLD_PCT: float = 5.0
    ALERT_DEDUP_TTL_SECONDS: int = 3600


@lru_cache
def get_settings() -> Settings:
    return Settings()
