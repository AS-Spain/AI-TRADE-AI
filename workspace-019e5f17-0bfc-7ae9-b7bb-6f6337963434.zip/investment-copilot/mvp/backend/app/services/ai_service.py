"""
AI Service — the production LLM integration layer.

Handles:
  - OpenAI / Anthropic API calls (streaming + non-streaming)
  - Context injection assembly
  - Short-term memory via Redis
  - Long-term memory recall via pgvector
  - Embedding generation
  - Response parsing + metadata extraction
"""
import json
import time
import uuid
from datetime import datetime, timezone
from typing import AsyncGenerator, Optional

import openai
from openai import AsyncOpenAI
import anthropic
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.logging import logger
from app.db.redis_client import redis_append_list, redis_get_list
from app.models.db_models import ChatMessage, MemoryChunk, Portfolio, User
from app.services.market_data import MarketDataService

settings = get_settings()

# ── Clients ───────────────────────────────────────────────────────────────────
_openai_client: Optional[AsyncOpenAI] = None
_anthropic_client: Optional[anthropic.AsyncAnthropic] = None


def get_openai() -> AsyncOpenAI:
    global _openai_client
    if _openai_client is None:
        _openai_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
    return _openai_client


def get_anthropic() -> anthropic.AsyncAnthropic:
    global _anthropic_client
    if _anthropic_client is None:
        _anthropic_client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
    return _anthropic_client


# ── System prompt ─────────────────────────────────────────────────────────────

def build_system_prompt(user: User) -> str:
    return f"""You are InvestIQ, an expert AI investment copilot. You assist users with portfolio analysis, investment research, risk management, and financial planning.

INVESTOR PROFILE:
- Risk Tolerance: {user.risk_tolerance}
- Investment Horizon: {user.investment_horizon_years} years
- Preferred Sectors: {", ".join(user.preferred_sectors) if user.preferred_sectors else "Diversified"}
- Restricted Assets: {", ".join(user.restricted_assets) if user.restricted_assets else "None"}
- Tax Jurisdiction: {user.tax_jurisdiction}

GUIDELINES:
1. Always ground your analysis in the portfolio data and market context provided
2. Cite specific data points (prices, percentages, ratios) in your responses
3. Clearly distinguish between facts (from data) and analysis (your interpretation)
4. Flag uncertainty explicitly — say "based on available data" or "this is uncertain"
5. Tailor all recommendations to the investor's risk tolerance and horizon
6. Always include a brief risk disclosure for any investment suggestions
7. Be concise but complete — bullet points for lists, prose for explanations
8. NEVER fabricate specific prices, earnings, or financial data not in the context

IMPORTANT: This is AI-assisted analysis, not licensed financial advice. Always remind the user to consult a qualified financial advisor for major decisions."""


# ── Embedding service ─────────────────────────────────────────────────────────

async def embed_text(text_input: str) -> list[float]:
    """Generate embedding via OpenAI. Returns 1536-dim vector."""
    try:
        client = get_openai()
        resp = await client.embeddings.create(
            model=settings.EMBEDDING_MODEL,
            input=text_input,
        )
        return resp.data[0].embedding
    except Exception as exc:
        logger.error("embedding_failed", error=str(exc))
        # Return zero vector as fallback (semantic search will still work, just poorly)
        return [0.0] * settings.VECTOR_DIMENSIONS


# ── Context injection ─────────────────────────────────────────────────────────

async def build_context(
    user: User,
    session_id: str,
    query: str,
    db: AsyncSession,
    market_svc: MarketDataService,
) -> tuple[dict, list[str]]:
    """
    Assemble the context dict to inject into the LLM prompt.
    Returns (context_dict, list_of_slots_used).
    """
    context: dict = {}
    slots_used: list[str] = []

    # 1. Portfolio state
    portfolio = await _get_portfolio_state(user.id, db, market_svc)
    if portfolio:
        context["portfolio"] = portfolio
        slots_used.append("portfolio")

    # 2. Short-term memory (conversation history)
    history = await redis_get_list(f"chat:{session_id}")
    if history:
        context["conversation_history"] = history[-10:]   # last 10 turns
        slots_used.append("conversation_history")

    # 3. Long-term memory recall (semantic)
    memories = await _recall_memory(user.id, query, db, top_k=4)
    if memories:
        context["relevant_memories"] = memories
        slots_used.append("long_term_memory")

    # 4. Live market data for holdings
    if portfolio and portfolio.get("holdings"):
        tickers = [h["ticker"] for h in portfolio["holdings"]][:10]
        quotes = await market_svc.get_quotes(tickers)
        context["live_quotes"] = quotes
        slots_used.append("live_quotes")

    # 5. Market news
    if portfolio and portfolio.get("holdings"):
        news = await market_svc.get_news(tickers[:5], limit=5)
        context["recent_news"] = news
        slots_used.append("market_news")

    # 6. Macro snapshot
    macro = await market_svc.get_macro_snapshot()
    context["macro_indicators"] = macro
    slots_used.append("macro_indicators")

    return context, slots_used


async def _get_portfolio_state(
    user_id: str, db: AsyncSession, market_svc: MarketDataService
) -> Optional[dict]:
    """Fetch portfolio with enriched holding data."""
    result = await db.execute(
        select(Portfolio)
        .where(Portfolio.user_id == user_id, Portfolio.is_default == True)
    )
    portfolio = result.scalar_one_or_none()
    if not portfolio:
        return None

    holdings_data = []
    total_cost = 0.0
    total_value = portfolio.cash_balance

    for h in portfolio.holdings:
        # Use cached price (refreshed by background task every 60s)
        price = h.current_price or h.avg_cost_basis
        mv = h.quantity * price
        cost = h.quantity * h.avg_cost_basis
        pnl = mv - cost
        total_value += mv
        total_cost += cost
        holdings_data.append({
            "ticker": h.ticker,
            "name": h.name,
            "sector": h.sector,
            "quantity": h.quantity,
            "avg_cost": h.avg_cost_basis,
            "current_price": price,
            "market_value": round(mv, 2),
            "unrealized_pnl": round(pnl, 2),
            "unrealized_pnl_pct": round((pnl / cost) * 100, 2) if cost else 0,
        })

    # Compute weights
    for h in holdings_data:
        h["weight_pct"] = round((h["market_value"] / total_value) * 100, 2) if total_value else 0

    # Sector allocation
    sector_alloc: dict[str, float] = {}
    for h in holdings_data:
        s = h.get("sector", "Unknown")
        sector_alloc[s] = sector_alloc.get(s, 0) + h["market_value"]
    sector_alloc_pct = {
        k: round((v / total_value) * 100, 2) for k, v in sector_alloc.items()
    } if total_value else {}

    total_pnl = total_value - total_cost - portfolio.cash_balance
    return {
        "name": portfolio.name,
        "total_value": round(total_value, 2),
        "cash_balance": portfolio.cash_balance,
        "total_cost": round(total_cost, 2),
        "total_unrealized_pnl": round(total_pnl, 2),
        "total_unrealized_pnl_pct": round((total_pnl / total_cost) * 100, 2) if total_cost else 0,
        "holdings": sorted(holdings_data, key=lambda x: x["market_value"], reverse=True),
        "sector_allocation": sector_alloc_pct,
        "num_positions": len(holdings_data),
    }


async def _recall_memory(
    user_id: str, query: str, db: AsyncSession, top_k: int = 4
) -> list[str]:
    """Vector similarity search over long-term memory chunks."""
    try:
        emb = await embed_text(query)
        # pgvector cosine similarity search
        result = await db.execute(
            text("""
                SELECT content
                FROM memory_chunks
                WHERE user_id = :user_id
                  AND (expires_at IS NULL OR expires_at > NOW())
                ORDER BY embedding <=> CAST(:emb AS vector)
                LIMIT :top_k
            """),
            {"user_id": user_id, "emb": str(emb), "top_k": top_k},
        )
        return [row[0] for row in result.fetchall()]
    except Exception as exc:
        logger.warning("memory_recall_failed", error=str(exc))
        return []


# ── Main AI chat function ─────────────────────────────────────────────────────

async def chat(
    user: User,
    session_id: str,
    user_message: str,
    db: AsyncSession,
    market_svc: MarketDataService,
    stream: bool = False,
) -> dict:
    """
    Full pipeline:
      1. Build context
      2. Call LLM
      3. Persist to Redis (short-term) + Postgres
      4. Return response
    """
    t0 = time.monotonic()

    # Build context
    context, slots_used = await build_context(
        user, session_id, user_message, db, market_svc
    )

    # Build messages
    system_prompt = build_system_prompt(user)
    context_block = json.dumps(context, indent=2, default=str)

    # Short-term history for this call
    history = await redis_get_list(f"chat:{session_id}")
    messages = []
    for msg in history[-8:]:   # last 8 turns to stay under token limit
        messages.append({"role": msg["role"], "content": msg["content"]})

    # Append current user message with context
    messages.append({
        "role": "user",
        "content": (
            f"<portfolio_context>\n{context_block}\n</portfolio_context>\n\n"
            f"{user_message}"
        ),
    })

    # Call LLM
    if settings.PRIMARY_LLM_PROVIDER == "anthropic" and settings.ANTHROPIC_API_KEY:
        response_data = await _call_anthropic(system_prompt, messages)
    elif settings.OPENAI_API_KEY:
        response_data = await _call_openai(system_prompt, messages)
    else:
        # Demo fallback — no API key
        response_data = _demo_response(user_message, context)

    latency_ms = int((time.monotonic() - t0) * 1000)
    message_id = str(uuid.uuid4())

    # Persist to Redis short-term memory
    await redis_append_list(f"chat:{session_id}", {
        "role": "user",
        "content": user_message,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })
    await redis_append_list(f"chat:{session_id}", {
        "role": "assistant",
        "content": response_data["content"],
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "model": response_data["model"],
    })

    # Persist to Postgres for history
    db.add(ChatMessage(
        id=message_id,
        user_id=user.id,
        session_id=session_id,
        role="user",
        content=user_message,
        created_at=datetime.now(timezone.utc),
    ))
    db.add(ChatMessage(
        user_id=user.id,
        session_id=session_id,
        role="assistant",
        content=response_data["content"],
        model_used=response_data["model"],
        tokens_used=response_data.get("tokens", 0),
        meta={"latency_ms": latency_ms, "slots_used": slots_used},
        created_at=datetime.now(timezone.utc),
    ))
    await db.flush()

    logger.info("chat_complete",
                user_id=user.id, session_id=session_id,
                model=response_data["model"], latency_ms=latency_ms,
                tokens=response_data.get("tokens", 0))

    return {
        "session_id": session_id,
        "message_id": message_id,
        "content": response_data["content"],
        "model_used": response_data["model"],
        "tokens_used": response_data.get("tokens", 0),
        "context_used": slots_used,
        "latency_ms": latency_ms,
    }


# ── Provider calls ────────────────────────────────────────────────────────────

async def _call_openai(system_prompt: str, messages: list[dict]) -> dict:
    client = get_openai()
    resp = await client.chat.completions.create(
        model=settings.PRIMARY_LLM_MODEL,
        messages=[{"role": "system", "content": system_prompt}] + messages,
        temperature=0.3,
        max_tokens=1200,
    )
    return {
        "content": resp.choices[0].message.content,
        "model": resp.model,
        "tokens": resp.usage.total_tokens if resp.usage else 0,
    }


async def _call_anthropic(system_prompt: str, messages: list[dict]) -> dict:
    client = get_anthropic()
    resp = await client.messages.create(
        model="claude-sonnet-4-5",
        system=system_prompt,
        messages=messages,
        max_tokens=1200,
        temperature=0.3,
    )
    return {
        "content": resp.content[0].text,
        "model": resp.model,
        "tokens": resp.usage.input_tokens + resp.usage.output_tokens,
    }


async def chat_stream(
    user: User,
    session_id: str,
    user_message: str,
    db: AsyncSession,
    market_svc: MarketDataService,
) -> AsyncGenerator[str, None]:
    """Server-Sent Events stream for real-time token delivery."""
    context, slots_used = await build_context(
        user, session_id, user_message, db, market_svc
    )
    system_prompt = build_system_prompt(user)
    context_block = json.dumps(context, indent=2, default=str)
    history = await redis_get_list(f"chat:{session_id}")
    messages = [{"role": m["role"], "content": m["content"]} for m in history[-8:]]
    messages.append({
        "role": "user",
        "content": f"<portfolio_context>\n{context_block}\n</portfolio_context>\n\n{user_message}",
    })

    full_content = []

    if settings.OPENAI_API_KEY:
        client = get_openai()
        stream = await client.chat.completions.create(
            model=settings.PRIMARY_LLM_MODEL,
            messages=[{"role": "system", "content": system_prompt}] + messages,
            temperature=0.3,
            max_tokens=1200,
            stream=True,
        )
        async for chunk in stream:
            delta = chunk.choices[0].delta.content or ""
            if delta:
                full_content.append(delta)
                yield f"data: {json.dumps({'type': 'token', 'content': delta})}\n\n"
    else:
        # Demo stream
        demo = _demo_response(user_message, context)["content"]
        for word in demo.split():
            yield f"data: {json.dumps({'type': 'token', 'content': word + ' '})}\n\n"
            import asyncio
            await asyncio.sleep(0.03)
        full_content = [demo]

    complete = "".join(full_content)
    yield f"data: {json.dumps({'type': 'done', 'session_id': session_id, 'slots_used': slots_used})}\n\n"

    # Persist
    await redis_append_list(f"chat:{session_id}", {"role": "user", "content": user_message})
    await redis_append_list(f"chat:{session_id}", {"role": "assistant", "content": complete})
    db.add(ChatMessage(user_id=user.id, session_id=session_id, role="user", content=user_message))
    db.add(ChatMessage(user_id=user.id, session_id=session_id, role="assistant",
                       content=complete, model_used=settings.PRIMARY_LLM_MODEL))
    await db.flush()


# ── Long-term memory ingestion ────────────────────────────────────────────────

async def ingest_session_to_memory(
    user_id: str, session_id: str, db: AsyncSession
) -> None:
    """
    At session end: extract key insights via LLM and store as memory chunks.
    Called by a background task.
    """
    history = await redis_get_list(f"chat:{session_id}")
    if len(history) < 2:
        return

    conversation_text = "\n".join(
        f"{m['role'].upper()}: {m['content']}" for m in history
    )

    extract_prompt = f"""Extract up to 5 key investment insights or preferences from this conversation.
Return as JSON array: [{{"content": "...", "type": "preference|decision|insight|fact", "importance": 0.0-1.0}}]
Only include genuinely useful long-term information. Skip small talk.

Conversation:
{conversation_text[:3000]}"""

    try:
        if settings.OPENAI_API_KEY:
            client = get_openai()
            resp = await client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": extract_prompt}],
                temperature=0.1,
                response_format={"type": "json_object"},
            )
            raw = json.loads(resp.choices[0].message.content)
            insights = raw if isinstance(raw, list) else raw.get("insights", [])
        else:
            return  # skip in demo mode

        for ins in insights[:5]:
            content = ins.get("content", "")
            if not content:
                continue
            emb = await embed_text(content)
            chunk = MemoryChunk(
                user_id=user_id,
                content=content,
                chunk_type=ins.get("type", "insight"),
                importance=float(ins.get("importance", 0.5)),
                embedding=emb,
                tags=[],
            )
            db.add(chunk)

        await db.flush()
        logger.info("memory_ingested", user_id=user_id, session_id=session_id,
                    chunks=len(insights))
    except Exception as exc:
        logger.error("memory_ingest_failed", error=str(exc))


# ── Demo fallback (no API keys) ───────────────────────────────────────────────

def _demo_response(query: str, context: dict) -> dict:
    portfolio = context.get("portfolio", {})
    total = portfolio.get("total_value", 0)
    pnl = portfolio.get("total_unrealized_pnl", 0)
    holdings = portfolio.get("holdings", [])
    n = len(holdings)

    content = f"""**Demo Mode** *(Connect an OpenAI or Anthropic API key for full AI responses)*

Based on your portfolio data, here's a brief analysis:

**Portfolio Summary**
- Total Value: ${total:,.2f}
- Unrealized P&L: ${pnl:,.2f} ({portfolio.get('total_unrealized_pnl_pct', 0):.1f}%)
- Number of Positions: {n}

**Regarding your question:** "{query}"

This is a demo response. In production with a valid API key, InvestIQ will:
- Analyze your specific portfolio composition and risk metrics
- Reference real-time market data and news for your holdings
- Recall past conversations and your investment preferences
- Provide detailed, cited analysis with explicit risk disclosures

To enable full AI capabilities, add your `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` to the `.env` file.

*This is AI-assisted analysis and not financial advice.*"""

    return {"content": content, "model": "demo", "tokens": 0}
