"""
Market data service.
Primary: Polygon.io REST API.
Fallback: returns plausible mock data so the app runs without API keys.
"""
import asyncio
import random
from datetime import datetime, timezone
from typing import Optional

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import get_settings
from app.core.logging import logger

settings = get_settings()

# Realistic mock prices for demo mode
MOCK_PRICES: dict[str, dict] = {
    "AAPL":  {"price": 213.55, "change": 1.23, "change_pct": 0.58,  "sector": "Technology"},
    "MSFT":  {"price": 420.21, "change": -2.14, "change_pct": -0.51, "sector": "Technology"},
    "GOOGL": {"price": 178.02, "change": 0.88, "change_pct": 0.50,  "sector": "Technology"},
    "AMZN":  {"price": 192.73, "change": 3.15, "change_pct": 1.66,  "sector": "Consumer Cyclical"},
    "NVDA":  {"price": 1089.89, "change": 22.40, "change_pct": 2.10, "sector": "Technology"},
    "META":  {"price": 504.22, "change": -5.11, "change_pct": -1.00, "sector": "Technology"},
    "TSLA":  {"price": 180.11, "change": -8.75, "change_pct": -4.64, "sector": "Consumer Cyclical"},
    "JPM":   {"price": 204.50, "change": 1.10, "change_pct": 0.54,  "sector": "Financials"},
    "V":     {"price": 278.90, "change": 0.45, "change_pct": 0.16,  "sector": "Financials"},
    "JNJ":   {"price": 147.30, "change": -0.30, "change_pct": -0.20, "sector": "Healthcare"},
    "SPY":   {"price": 537.22, "change": 2.11, "change_pct": 0.39,  "sector": "ETF"},
    "QQQ":   {"price": 461.18, "change": 3.44, "change_pct": 0.75,  "sector": "ETF"},
    "BND":   {"price": 72.45,  "change": -0.05, "change_pct": -0.07, "sector": "Bond ETF"},
    "GLD":   {"price": 225.33, "change": 1.20, "change_pct": 0.54,  "sector": "Commodity"},
}


def _add_noise(base: float, pct: float = 0.005) -> float:
    """Simulate slight real-time price drift."""
    return round(base * (1 + random.uniform(-pct, pct)), 2)


class MarketDataService:
    """
    All market data calls go through this service.
    Uses Polygon.io when POLYGON_API_KEY is set; otherwise uses mock data.
    """

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=10.0)
        self._use_real = bool(settings.POLYGON_API_KEY)
        if not self._use_real:
            logger.warning("POLYGON_API_KEY not set — using mock market data")

    # ── Public API ────────────────────────────────────────────────────────────

    async def get_quote(self, ticker: str) -> dict:
        ticker = ticker.upper()
        if self._use_real:
            return await self._polygon_quote(ticker)
        return self._mock_quote(ticker)

    async def get_quotes(self, tickers: list[str]) -> dict[str, dict]:
        tasks = [self.get_quote(t) for t in tickers]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return {
            t: r if not isinstance(r, Exception) else self._mock_quote(t)
            for t, r in zip(tickers, results)
        }

    async def get_news(self, tickers: list[str], limit: int = 5) -> list[dict]:
        if self._use_real:
            return await self._polygon_news(tickers, limit)
        return self._mock_news(tickers, limit)

    async def get_macro_snapshot(self) -> dict:
        """Returns key macro indicators (mocked for MVP)."""
        return {
            "fed_funds_rate": 5.33,
            "cpi_yoy": 3.4,
            "unemployment": 3.9,
            "vix": 14.2,
            "10y_treasury": 4.51,
            "sp500_pe": 24.1,
            "as_of": datetime.now(timezone.utc).isoformat(),
        }

    # ── Polygon.io ────────────────────────────────────────────────────────────

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
    async def _polygon_quote(self, ticker: str) -> dict:
        url = f"https://api.polygon.io/v2/last/trade/{ticker}"
        r = await self._client.get(
            url, params={"apiKey": settings.POLYGON_API_KEY}
        )
        r.raise_for_status()
        data = r.json()
        trade = data.get("results", {})
        # Also fetch previous close for change calc
        prev = await self._polygon_prev_close(ticker)
        price = trade.get("p", 0.0)
        change = round(price - prev, 2)
        change_pct = round((change / prev) * 100, 2) if prev else 0.0
        return {
            "ticker": ticker,
            "price": price,
            "change": change,
            "change_pct": change_pct,
            "volume": trade.get("s", 0),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

    async def _polygon_prev_close(self, ticker: str) -> float:
        url = f"https://api.polygon.io/v2/aggs/ticker/{ticker}/prev"
        r = await self._client.get(url, params={"apiKey": settings.POLYGON_API_KEY})
        r.raise_for_status()
        results = r.json().get("results", [{}])
        return results[0].get("c", 0.0) if results else 0.0

    async def _polygon_news(self, tickers: list[str], limit: int) -> list[dict]:
        url = "https://api.polygon.io/v2/reference/news"
        r = await self._client.get(url, params={
            "ticker": ",".join(tickers[:5]),
            "limit": limit,
            "apiKey": settings.POLYGON_API_KEY,
        })
        r.raise_for_status()
        items = r.json().get("results", [])
        return [
            {
                "title": i.get("title"),
                "summary": i.get("description", ""),
                "url": i.get("article_url", ""),
                "tickers": i.get("tickers", []),
                "published_at": i.get("published_utc", ""),
                "sentiment": i.get("insights", [{}])[0].get("sentiment", "neutral")
                            if i.get("insights") else "neutral",
            }
            for i in items
        ]

    # ── Mock fallbacks ────────────────────────────────────────────────────────

    def _mock_quote(self, ticker: str) -> dict:
        base = MOCK_PRICES.get(ticker, {
            "price": 100.0, "change": 0.0, "change_pct": 0.0, "sector": "Unknown"
        })
        price = _add_noise(base["price"])
        prev  = price - base["change"]
        return {
            "ticker": ticker,
            "price": price,
            "change": round(price - prev, 2),
            "change_pct": base["change_pct"],
            "volume": random.randint(1_000_000, 80_000_000),
            "market_cap": round(price * random.uniform(1e9, 3e12)),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

    def _mock_news(self, tickers: list[str], limit: int) -> list[dict]:
        headlines = [
            {"title": f"{tickers[0] if tickers else 'Market'} beats Q2 earnings estimates",
             "sentiment": "positive"},
            {"title": "Fed signals rate path unchanged through summer",
             "sentiment": "neutral"},
            {"title": f"Analysts raise price target on {tickers[0] if tickers else 'SPY'}",
             "sentiment": "positive"},
            {"title": "Tech sector faces headwinds from rising yields",
             "sentiment": "negative"},
            {"title": "Consumer spending remains resilient in latest data",
             "sentiment": "positive"},
        ]
        return [
            {**h, "url": "#", "tickers": tickers[:2],
             "published_at": datetime.now(timezone.utc).isoformat(),
             "summary": h["title"] + ". Full analysis available."}
            for h in headlines[:limit]
        ]
