"""
Portfolio CRUD + enrichment service.
Computes P&L, weights, sector allocation, and risk metrics.
"""
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.db_models import Holding, Portfolio, User
from app.models.schemas import HoldingCreate, HoldingOut, PortfolioOut
from app.services.market_data import MarketDataService


async def get_or_create_default_portfolio(
    user: User, db: AsyncSession
) -> Portfolio:
    """Ensure every user has exactly one default portfolio."""
    result = await db.execute(
        select(Portfolio).where(Portfolio.user_id == user.id, Portfolio.is_default == True)
    )
    portfolio = result.scalar_one_or_none()
    if portfolio:
        return portfolio

    portfolio = Portfolio(
        user_id=user.id,
        name="My Portfolio",
        is_default=True,
        cash_balance=10_000.0,
    )
    db.add(portfolio)
    await db.flush()
    return portfolio


async def get_enriched_portfolio(
    user: User, db: AsyncSession, market_svc: MarketDataService
) -> PortfolioOut:
    portfolio = await get_or_create_default_portfolio(user, db)

    # Refresh live prices
    if portfolio.holdings:
        tickers = [h.ticker for h in portfolio.holdings]
        quotes = await market_svc.get_quotes(tickers)
        for h in portfolio.holdings:
            q = quotes.get(h.ticker, {})
            if q.get("price"):
                h.current_price = q["price"]
                h.price_change_pct = q.get("change_pct", 0.0)
                h.last_price_update = datetime.now(timezone.utc)
        await db.flush()

    # Compute portfolio metrics
    total_cost = sum(h.quantity * h.avg_cost_basis for h in portfolio.holdings)
    holdings_value = sum(
        h.quantity * (h.current_price or h.avg_cost_basis)
        for h in portfolio.holdings
    )
    total_value = holdings_value + portfolio.cash_balance
    total_pnl = holdings_value - total_cost
    total_pnl_pct = (total_pnl / total_cost * 100) if total_cost else 0.0

    # Day change (sum of holding day changes)
    day_change_abs = sum(
        h.quantity * (h.current_price or 0) * (h.price_change_pct / 100)
        for h in portfolio.holdings
    )
    day_change_pct = (day_change_abs / total_value * 100) if total_value else 0.0

    holding_outs: list[HoldingOut] = []
    for h in portfolio.holdings:
        price = h.current_price or h.avg_cost_basis
        mv = h.quantity * price
        cost = h.quantity * h.avg_cost_basis
        pnl = mv - cost
        pnl_pct = (pnl / cost * 100) if cost else 0.0
        weight = (mv / total_value * 100) if total_value else 0.0
        holding_outs.append(HoldingOut(
            id=h.id,
            ticker=h.ticker,
            name=h.name,
            asset_class=h.asset_class,
            sector=h.sector,
            geography=h.geography,
            currency=h.currency,
            quantity=h.quantity,
            avg_cost_basis=h.avg_cost_basis,
            current_price=price,
            price_change_pct=h.price_change_pct,
            market_value=round(mv, 2),
            unrealized_pnl=round(pnl, 2),
            unrealized_pnl_pct=round(pnl_pct, 2),
            weight=round(weight, 2),
        ))

    return PortfolioOut(
        id=portfolio.id,
        name=portfolio.name,
        cash_balance=portfolio.cash_balance,
        total_value=round(total_value, 2),
        total_cost=round(total_cost, 2),
        total_unrealized_pnl=round(total_pnl, 2),
        total_unrealized_pnl_pct=round(total_pnl_pct, 2),
        day_change=round(day_change_abs, 2),
        day_change_pct=round(day_change_pct, 2),
        holdings=sorted(holding_outs, key=lambda x: x.market_value, reverse=True),
    )


async def add_holding(
    user: User, data: HoldingCreate, db: AsyncSession
) -> Holding:
    portfolio = await get_or_create_default_portfolio(user, db)

    # Check if holding already exists
    result = await db.execute(
        select(Holding).where(
            Holding.portfolio_id == portfolio.id,
            Holding.ticker == data.ticker,
        )
    )
    existing = result.scalar_one_or_none()
    if existing:
        # Average up / down
        total_qty = existing.quantity + data.quantity
        existing.avg_cost_basis = (
            (existing.quantity * existing.avg_cost_basis + data.quantity * data.avg_cost_basis)
            / total_qty
        )
        existing.quantity = total_qty
        await db.flush()
        return existing

    holding = Holding(
        portfolio_id=portfolio.id,
        **data.model_dump(),
    )
    db.add(holding)
    await db.flush()
    return holding


async def remove_holding(
    user: User, holding_id: str, db: AsyncSession
) -> bool:
    portfolio = await get_or_create_default_portfolio(user, db)
    result = await db.execute(
        select(Holding).where(
            Holding.id == holding_id,
            Holding.portfolio_id == portfolio.id,
        )
    )
    holding = result.scalar_one_or_none()
    if not holding:
        return False
    await db.delete(holding)
    await db.flush()
    return True


async def update_cash(
    user: User, amount: float, db: AsyncSession
) -> Portfolio:
    portfolio = await get_or_create_default_portfolio(user, db)
    portfolio.cash_balance = max(0.0, amount)
    await db.flush()
    return portfolio


def compute_sector_allocation(holdings: list[HoldingOut], total_value: float) -> dict[str, float]:
    alloc: dict[str, float] = {}
    for h in holdings:
        alloc[h.sector] = alloc.get(h.sector, 0.0) + h.market_value
    return {k: round(v / total_value * 100, 2) for k, v in alloc.items()} if total_value else {}
