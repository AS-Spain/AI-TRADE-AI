"""Alerts endpoints — list, mark read, dismiss."""
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.db.database import get_db
from app.models.db_models import Alert, User
from app.models.schemas import AlertOut

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("", response_model=list[AlertOut])
async def list_alerts(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    unread_only: bool = False,
    limit: Annotated[int, Query(ge=1, le=100)] = 20,
):
    q = select(Alert).where(Alert.user_id == user.id)
    if unread_only:
        q = q.where(Alert.is_read == False)
    q = q.order_by(Alert.created_at.desc()).limit(limit)
    result = await db.execute(q)
    return result.scalars().all()


@router.patch("/{alert_id}/read", response_model=AlertOut)
async def mark_read(
    alert_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Alert).where(Alert.id == alert_id, Alert.user_id == user.id)
    )
    alert = result.scalar_one_or_none()
    if alert:
        alert.is_read = True
        await db.flush()
    return alert


@router.patch("/read-all", response_model=dict)
async def mark_all_read(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await db.execute(
        update(Alert)
        .where(Alert.user_id == user.id, Alert.is_read == False)
        .values(is_read=True)
    )
    await db.flush()
    return {"status": "all_read"}


@router.get("/unread-count", response_model=dict)
async def unread_count(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Alert).where(Alert.user_id == user.id, Alert.is_read == False)
    )
    count = len(result.scalars().all())
    return {"count": count}
