"""Aggregated dashboard endpoint — single request for all dashboard data."""
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_market_svc
from app.db.database import get_db
from app.models.db_models import Alert, User
from app.models.schemas import DashboardOut
from app.services.market_data import MarketDataService
from app.services.portfolio_service import (
    compute_sector_allocation, get_enriched_portfolio
)

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("", response_model=DashboardOut)
async def dashboard(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    # 1. Portfolio (with live prices)
    portfolio = await get_enriched_portfolio(user, db, market_svc)

    # 2. Alerts
    alerts_result = await db.execute(
        select(Alert)
        .where(Alert.user_id == user.id)
        .order_by(Alert.created_at.desc())
        .limit(5)
    )
    recent_alerts = alerts_result.scalars().all()
    unread_count = sum(1 for a in recent_alerts if not a.is_read)

    # 3. Top movers (largest absolute day change)
    top_movers = sorted(
        portfolio.holdings,
        key=lambda h: abs(h.price_change_pct),
        reverse=True,
    )[:5]

    # 4. Sector allocation
    sector_alloc = compute_sector_allocation(portfolio.holdings, portfolio.total_value)

    return DashboardOut(
        portfolio=portfolio,
        unread_alerts=unread_count,
        recent_alerts=recent_alerts,
        top_movers=top_movers,
        sector_allocation=sector_alloc,
    )
