"""Market data pass-through endpoints."""
from fastapi import APIRouter, Depends

from app.api.deps import get_current_user, get_market_svc
from app.models.db_models import User
from app.services.market_data import MarketDataService

router = APIRouter(prefix="/market", tags=["market"])


@router.get("/quote/{ticker}")
async def get_quote(
    ticker: str,
    user: User = Depends(get_current_user),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    return await market_svc.get_quote(ticker.upper())


@router.get("/quotes")
async def get_quotes(
    tickers: str,   # comma-separated: "AAPL,MSFT,GOOGL"
    user: User = Depends(get_current_user),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    ticker_list = [t.strip().upper() for t in tickers.split(",") if t.strip()][:20]
    return await market_svc.get_quotes(ticker_list)


@router.get("/news")
async def get_news(
    tickers: str,
    limit: int = 10,
    user: User = Depends(get_current_user),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    ticker_list = [t.strip().upper() for t in tickers.split(",") if t.strip()][:10]
    return await market_svc.get_news(ticker_list, limit=limit)


@router.get("/macro")
async def macro_snapshot(
    user: User = Depends(get_current_user),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    return await market_svc.get_macro_snapshot()
