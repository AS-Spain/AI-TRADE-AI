"""Portfolio CRUD + enrichment endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_market_svc
from app.db.database import get_db
from app.models.db_models import User
from app.models.schemas import (
    HoldingCreate, HoldingOut, PortfolioCashUpdate, PortfolioOut
)
from app.services.market_data import MarketDataService
from app.services.portfolio_service import (
    add_holding, get_enriched_portfolio, remove_holding,
    update_cash, compute_sector_allocation,
)

router = APIRouter(prefix="/portfolio", tags=["portfolio"])


@router.get("", response_model=PortfolioOut)
async def get_portfolio(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    return await get_enriched_portfolio(user, db, market_svc)


@router.post("/holdings", response_model=HoldingOut, status_code=201)
async def add_position(
    data: HoldingCreate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    holding = await add_holding(user, data, db)
    # Enrich with live price
    quote = await market_svc.get_quote(holding.ticker)
    price = quote.get("price", holding.avg_cost_basis)
    mv = holding.quantity * price
    cost = holding.quantity * holding.avg_cost_basis
    pnl = mv - cost
    return HoldingOut(
        id=holding.id,
        ticker=holding.ticker,
        name=holding.name,
        asset_class=holding.asset_class,
        sector=holding.sector,
        geography=holding.geography,
        currency=holding.currency,
        quantity=holding.quantity,
        avg_cost_basis=holding.avg_cost_basis,
        current_price=price,
        price_change_pct=quote.get("change_pct", 0.0),
        market_value=round(mv, 2),
        unrealized_pnl=round(pnl, 2),
        unrealized_pnl_pct=round((pnl / cost * 100) if cost else 0, 2),
        weight=0.0,  # will be recalculated on next full portfolio fetch
    )


@router.delete("/holdings/{holding_id}", status_code=204)
async def remove_position(
    holding_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    removed = await remove_holding(user, holding_id, db)
    if not removed:
        raise HTTPException(status_code=404, detail="Holding not found")


@router.patch("/cash", response_model=dict)
async def set_cash(
    data: PortfolioCashUpdate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    portfolio = await update_cash(user, data.amount, db)
    return {"cash_balance": portfolio.cash_balance}


@router.get("/sector-allocation", response_model=dict)
async def sector_allocation(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    portfolio = await get_enriched_portfolio(user, db, market_svc)
    alloc = compute_sector_allocation(portfolio.holdings, portfolio.total_value)
    return {"allocation": alloc}
