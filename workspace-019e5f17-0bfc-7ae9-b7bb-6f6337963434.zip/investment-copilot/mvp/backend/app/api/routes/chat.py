"""
AI Chat endpoints.
  POST /chat        — standard request/response
  POST /chat/stream — Server-Sent Events stream
  GET  /chat/history/{session_id}
  POST /chat/session/end — trigger memory ingestion
"""
import uuid
from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, Depends, Query
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_market_svc
from app.db.database import get_db
from app.db.redis_client import redis_get_list
from app.models.db_models import ChatMessage, User
from app.models.schemas import ChatRequest, ChatResponse
from app.services.ai_service import chat, chat_stream, ingest_session_to_memory
from app.services.market_data import MarketDataService

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat_endpoint(
    req: ChatRequest,
    background_tasks: BackgroundTasks,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    session_id = req.session_id or str(uuid.uuid4())
    result = await chat(user, session_id, req.message, db, market_svc)
    return ChatResponse(**result)


@router.post("/stream")
async def chat_stream_endpoint(
    req: ChatRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    market_svc: MarketDataService = Depends(get_market_svc),
):
    """Server-Sent Events streaming endpoint."""
    session_id = req.session_id or str(uuid.uuid4())

    async def event_generator():
        async for chunk in chat_stream(user, session_id, req.message, db, market_svc):
            yield chunk

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Session-Id": session_id,
        },
    )


@router.get("/history/{session_id}")
async def get_chat_history(
    session_id: str,
    user: User = Depends(get_current_user),
    limit: Annotated[int, Query(ge=1, le=100)] = 50,
):
    """Return conversation history from Redis."""
    history = await redis_get_list(f"chat:{session_id}")
    return {"session_id": session_id, "messages": history[-limit:]}


@router.get("/sessions")
async def list_sessions(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List distinct session IDs for the user (from Postgres)."""
    result = await db.execute(
        select(ChatMessage.session_id, ChatMessage.created_at)
        .where(ChatMessage.user_id == user.id)
        .distinct(ChatMessage.session_id)
        .order_by(ChatMessage.created_at.desc())
        .limit(20)
    )
    rows = result.fetchall()
    return {"sessions": [{"session_id": r[0], "created_at": r[1]} for r in rows]}


@router.post("/session/{session_id}/end")
async def end_session(
    session_id: str,
    background_tasks: BackgroundTasks,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Trigger long-term memory ingestion from this session.
    Run as background task so the response is immediate.
    """
    background_tasks.add_task(ingest_session_to_memory, user.id, session_id, db)
    return {"status": "memory_ingestion_queued", "session_id": session_id}
