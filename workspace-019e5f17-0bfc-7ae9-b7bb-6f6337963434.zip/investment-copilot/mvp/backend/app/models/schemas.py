"""Pydantic v2 request / response schemas."""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, field_validator


# ── Auth ──────────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str


# ── User / Profile ────────────────────────────────────────────────────────────

class UserProfileUpdate(BaseModel):
    risk_tolerance: Optional[str] = None
    investment_horizon_years: Optional[int] = None
    preferred_sectors: Optional[list[str]] = None
    restricted_assets: Optional[list[str]] = None
    tax_jurisdiction: Optional[str] = None
    liquidity_need_pct: Optional[float] = None


class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    risk_tolerance: str
    investment_horizon_years: int
    preferred_sectors: list[str]
    restricted_assets: list[str]
    tax_jurisdiction: str
    liquidity_need_pct: float
    created_at: datetime

    model_config = {"from_attributes": True}


# ── Holdings / Portfolio ──────────────────────────────────────────────────────

class HoldingCreate(BaseModel):
    ticker: str
    name: str = ""
    asset_class: str = "equity"
    sector: str = "Unknown"
    geography: str = "US"
    currency: str = "USD"
    quantity: float
    avg_cost_basis: float

    @field_validator("ticker")
    @classmethod
    def upper_ticker(cls, v: str) -> str:
        return v.upper().strip()

    @field_validator("quantity", "avg_cost_basis")
    @classmethod
    def positive(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("Must be positive")
        return v


class HoldingUpdate(BaseModel):
    quantity: Optional[float] = None
    avg_cost_basis: Optional[float] = None
    sector: Optional[str] = None


class HoldingOut(BaseModel):
    id: str
    ticker: str
    name: str
    asset_class: str
    sector: str
    geography: str
    currency: str
    quantity: float
    avg_cost_basis: float
    current_price: float
    price_change_pct: float
    market_value: float
    unrealized_pnl: float
    unrealized_pnl_pct: float
    weight: float

    model_config = {"from_attributes": True}


class PortfolioOut(BaseModel):
    id: str
    name: str
    cash_balance: float
    total_value: float
    total_cost: float
    total_unrealized_pnl: float
    total_unrealized_pnl_pct: float
    day_change: float
    day_change_pct: float
    holdings: list[HoldingOut]

    model_config = {"from_attributes": True}


class PortfolioCashUpdate(BaseModel):
    amount: float


# ── Chat ─────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None      # None → backend creates new session
    stream: bool = False


class ChatResponse(BaseModel):
    session_id: str
    message_id: str
    content: str
    model_used: str
    tokens_used: int
    context_used: list[str]               # which context slots were filled


# ── Alerts ────────────────────────────────────────────────────────────────────

class AlertOut(BaseModel):
    id: str
    severity: str
    category: str
    title: str
    body: str
    ticker: Optional[str]
    is_read: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ── Market Data ───────────────────────────────────────────────────────────────

class QuoteOut(BaseModel):
    ticker: str
    price: float
    change: float
    change_pct: float
    volume: int
    market_cap: Optional[float]
    updated_at: datetime


# ── Dashboard ─────────────────────────────────────────────────────────────────

class DashboardOut(BaseModel):
    portfolio: PortfolioOut
    unread_alerts: int
    recent_alerts: list[AlertOut]
    top_movers: list[HoldingOut]
    sector_allocation: dict[str, float]
