"""Async Redis client (session memory + caching)."""
import json
from typing import Any, Optional

import redis.asyncio as aioredis

from app.core.config import get_settings

settings = get_settings()

_pool: Optional[aioredis.Redis] = None


async def get_redis() -> aioredis.Redis:
    global _pool
    if _pool is None:
        _pool = await aioredis.from_url(
            settings.REDIS_URL, encoding="utf-8", decode_responses=True
        )
    return _pool


# ── Convenience helpers ────────────────────────────────────────────────────

async def redis_set(key: str, value: Any, ttl: int = 3600) -> None:
    r = await get_redis()
    await r.set(key, json.dumps(value), ex=ttl)


async def redis_get(key: str) -> Optional[Any]:
    r = await get_redis()
    raw = await r.get(key)
    return json.loads(raw) if raw else None


async def redis_delete(key: str) -> None:
    r = await get_redis()
    await r.delete(key)


async def redis_append_list(key: str, value: Any, ttl: int = 7200, max_len: int = 50) -> None:
    """Append to a Redis list, trim to max_len, refresh TTL."""
    r = await get_redis()
    pipe = r.pipeline()
    pipe.rpush(key, json.dumps(value))
    pipe.ltrim(key, -max_len, -1)
    pipe.expire(key, ttl)
    await pipe.execute()


async def redis_get_list(key: str) -> list[Any]:
    r = await get_redis()
    items = await r.lrange(key, 0, -1)
    return [json.loads(i) for i in items]
