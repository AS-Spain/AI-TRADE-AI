"use client";
import type { Holding } from "@/lib/api";
import clsx from "clsx";

function fmt(n: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);
}

export function HoldingsTable({ holdings, totalValue }: { holdings: Holding[]; totalValue: number }) {
  return (
    <div className="card">
      <h3 className="font-semibold text-sm mb-4">Holdings</h3>
      {holdings.length === 0 ? (
        <p className="text-slate-500 text-sm py-8 text-center">
          No positions yet — add holdings in the Portfolio page.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-slate-500 text-xs uppercase tracking-wide border-b border-surface-border">
                <th className="text-left pb-3 pr-4">Ticker</th>
                <th className="text-right pb-3 pr-4">Price</th>
                <th className="text-right pb-3 pr-4">Change</th>
                <th className="text-right pb-3 pr-4">Mkt Value</th>
                <th className="text-right pb-3 pr-4">Unreal. P&L</th>
                <th className="text-right pb-3">Weight</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border/50">
              {holdings.map((h) => (
                <tr key={h.id} className="hover:bg-surface-border/20 transition-colors">
                  <td className="py-3 pr-4">
                    <div className="font-semibold text-white">{h.ticker}</div>
                    <div className="text-xs text-slate-500 truncate max-w-[120px]">{h.sector}</div>
                  </td>
                  <td className="text-right py-3 pr-4 font-mono">
                    {fmt(h.current_price)}
                  </td>
                  <td className={clsx("text-right py-3 pr-4 font-mono text-xs font-semibold",
                    h.price_change_pct >= 0 ? "text-emerald-400" : "text-red-400"
                  )}>
                    {h.price_change_pct >= 0 ? "+" : ""}{h.price_change_pct.toFixed(2)}%
                  </td>
                  <td className="text-right py-3 pr-4 font-mono">
                    {fmt(h.market_value)}
                  </td>
                  <td className={clsx("text-right py-3 pr-4 font-mono text-xs",
                    h.unrealized_pnl >= 0 ? "text-emerald-400" : "text-red-400"
                  )}>
                    <div>{h.unrealized_pnl >= 0 ? "+" : ""}{fmt(h.unrealized_pnl)}</div>
                    <div>{h.unrealized_pnl_pct >= 0 ? "+" : ""}{h.unrealized_pnl_pct.toFixed(1)}%</div>
                  </td>
                  <td className="text-right py-3">
                    <div className="flex items-center justify-end gap-2">
                      <div className="w-16 bg-surface-border rounded-full h-1.5">
                        <div
                          className="bg-brand-500 h-1.5 rounded-full"
                          style={{ width: `${Math.min(h.weight, 100)}%` }}
                        />
                      </div>
                      <span className="text-xs text-slate-400 w-10 text-right">
                        {h.weight.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
