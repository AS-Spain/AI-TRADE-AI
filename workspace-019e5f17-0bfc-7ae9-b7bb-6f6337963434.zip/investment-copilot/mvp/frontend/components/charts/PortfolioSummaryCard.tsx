"use client";
import { TrendingUp, TrendingDown, DollarSign, BarChart2 } from "lucide-react";
import type { Portfolio } from "@/lib/api";

function fmt(n: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(n);
}

function pct(n: number) {
  return `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`;
}

export function PortfolioSummaryCard({ portfolio }: { portfolio: Portfolio }) {
  const isUp = portfolio.total_unrealized_pnl >= 0;
  const dayUp = portfolio.day_change >= 0;

  const stats = [
    {
      label: "Total Value",
      value: fmt(portfolio.total_value),
      icon: DollarSign,
      color: "text-brand-400",
      bg: "bg-brand-400/10",
    },
    {
      label: "Unrealized P&L",
      value: fmt(portfolio.total_unrealized_pnl),
      sub: pct(portfolio.total_unrealized_pnl_pct),
      icon: isUp ? TrendingUp : TrendingDown,
      color: isUp ? "text-emerald-400" : "text-red-400",
      bg: isUp ? "bg-emerald-400/10" : "bg-red-400/10",
    },
    {
      label: "Today's Change",
      value: fmt(portfolio.day_change),
      sub: pct(portfolio.day_change_pct),
      icon: dayUp ? TrendingUp : TrendingDown,
      color: dayUp ? "text-emerald-400" : "text-red-400",
      bg: dayUp ? "bg-emerald-400/10" : "bg-red-400/10",
    },
    {
      label: "Positions",
      value: portfolio.holdings.length.toString(),
      sub: `+ ${fmt(portfolio.cash_balance)} cash`,
      icon: BarChart2,
      color: "text-violet-400",
      bg: "bg-violet-400/10",
    },
  ];

  return (
    <div className="grid grid-cols-4 gap-4">
      {stats.map((s) => (
        <div key={s.label} className="card flex items-start gap-4">
          <div className={`w-10 h-10 ${s.bg} rounded-lg flex items-center justify-center shrink-0`}>
            <s.icon className={`w-5 h-5 ${s.color}`} />
          </div>
          <div>
            <p className="text-slate-400 text-xs mb-0.5">{s.label}</p>
            <p className={`font-bold text-lg ${s.color}`}>{s.value}</p>
            {s.sub && <p className="text-slate-500 text-xs">{s.sub}</p>}
          </div>
        </div>
      ))}
    </div>
  );
}
