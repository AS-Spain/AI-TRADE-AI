"use client";
import Link from "next/link";
import type { Alert } from "@/lib/api";
import { Bell, AlertTriangle, Info, XCircle } from "lucide-react";
import clsx from "clsx";
import { formatDistanceToNow } from "date-fns";

const SEVERITY_STYLE = {
  info:     { icon: Info,          color: "text-blue-400",   bg: "bg-blue-400/10" },
  warning:  { icon: AlertTriangle, color: "text-amber-400",  bg: "bg-amber-400/10" },
  critical: { icon: XCircle,       color: "text-red-400",    bg: "bg-red-400/10" },
};

export function AlertsFeed({ alerts, unread }: { alerts: Alert[]; unread: number }) {
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-sm">Recent Alerts</h3>
          {unread > 0 && (
            <span className="bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">{unread}</span>
          )}
        </div>
        <Link href="/alerts" className="text-xs text-brand-400 hover:text-brand-300">
          View all →
        </Link>
      </div>

      {alerts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-slate-500">
          <Bell className="w-8 h-8 mb-2 opacity-30" />
          <p className="text-sm">No alerts</p>
        </div>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert) => {
            const s = SEVERITY_STYLE[alert.severity] || SEVERITY_STYLE.info;
            return (
              <div
                key={alert.id}
                className={clsx(
                  "flex gap-3 p-3 rounded-lg",
                  s.bg,
                  !alert.is_read && "ring-1 ring-inset ring-current/20"
                )}
              >
                <s.icon className={`w-4 h-4 ${s.color} shrink-0 mt-0.5`} />
                <div className="min-w-0">
                  <p className={`text-xs font-semibold ${s.color}`}>{alert.title}</p>
                  <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">{alert.body}</p>
                  <p className="text-xs text-slate-600 mt-1">
                    {formatDistanceToNow(new Date(alert.created_at), { addSuffix: true })}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
