"use client";
import type { Holding } from "@/lib/api";
import clsx from "clsx";

export function TopMovers({ movers }: { movers: Holding[] }) {
  return (
    <div className="card">
      <h3 className="font-semibold text-sm mb-4">Top Movers</h3>
      {movers.length === 0 ? (
        <p className="text-slate-500 text-sm text-center py-4">No data</p>
      ) : (
        <div className="space-y-2">
          {movers.slice(0, 5).map((h) => (
            <div key={h.id} className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm text-white">{h.ticker}</span>
                <span className="text-xs text-slate-500 ml-1.5">{h.sector}</span>
              </div>
              <span className={clsx(
                "text-xs font-semibold px-2 py-0.5 rounded",
                h.price_change_pct >= 0
                  ? "bg-emerald-400/10 text-emerald-400"
                  : "bg-red-400/10 text-red-400"
              )}>
                {h.price_change_pct >= 0 ? "+" : ""}{h.price_change_pct.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
