"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useChatStore } from "@/lib/store";
import { chatApi } from "@/lib/api";
import { MessageSquare, ArrowRight, Loader2 } from "lucide-react";

const QUICK_PROMPTS = [
  "How is my portfolio performing today?",
  "Which positions are over-concentrated?",
  "What's my biggest risk right now?",
  "Suggest a rebalancing strategy",
];

export function QuickChat() {
  const router = useRouter();
  const { addMessage, setSessionId, setTyping } = useChatStore();
  const [loading, setLoading] = useState(false);

  async function askQuick(prompt: string) {
    setLoading(true);
    try {
      const res = await chatApi.send(prompt);
      setSessionId(res.data.session_id);
      addMessage({ role: "user", content: prompt });
      addMessage({ role: "assistant", content: res.data.content });
      router.push("/chat");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-4">
        <MessageSquare className="w-4 h-4 text-brand-400" />
        <h3 className="font-semibold text-sm">Ask the AI Copilot</h3>
      </div>
      <div className="space-y-2">
        {QUICK_PROMPTS.map((p) => (
          <button
            key={p}
            onClick={() => askQuick(p)}
            disabled={loading}
            className="w-full text-left text-sm px-3 py-2.5 rounded-lg bg-surface border border-surface-border
                       hover:border-brand-500/50 hover:bg-brand-600/5 transition-all
                       text-slate-300 hover:text-white flex items-center justify-between group disabled:opacity-50"
          >
            <span>{p}</span>
            {loading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-500" />
            ) : (
              <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-brand-400 transition-colors" />
            )}
          </button>
        ))}
      </div>
      <button
        onClick={() => router.push("/chat")}
        className="w-full mt-3 btn-primary text-sm"
      >
        Open Full Copilot →
      </button>
    </div>
  );
}
