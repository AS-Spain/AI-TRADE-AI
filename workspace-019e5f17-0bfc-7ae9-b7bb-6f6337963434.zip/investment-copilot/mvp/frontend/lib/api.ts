/**
 * Typed API client — wraps axios with auth injection and error handling.
 */
import axios, { AxiosInstance } from "axios";

const BASE = process.env.NEXT_PUBLIC_API_URL
  ? `${process.env.NEXT_PUBLIC_API_URL}/api/v1`
  : "/api/v1";

function createClient(): AxiosInstance {
  const client = axios.create({ baseURL: BASE });

  client.interceptors.request.use((config) => {
    if (typeof window !== "undefined") {
      const token = localStorage.getItem("token");
      if (token) config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

  client.interceptors.response.use(
    (r) => r,
    (err) => {
      if (err.response?.status === 401 && typeof window !== "undefined") {
        localStorage.removeItem("token");
        window.location.href = "/login";
      }
      return Promise.reject(err);
    }
  );

  return client;
}

export const api = createClient();

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authApi = {
  register: (email: string, password: string, full_name: string) =>
    api.post("/auth/register", { email, password, full_name }),
  login: (email: string, password: string) =>
    api.post("/auth/login", { email, password }),
  me: () => api.get("/auth/me"),
  updateProfile: (data: Partial<UserProfile>) => api.patch("/auth/me/profile", data),
};

// ── Portfolio ─────────────────────────────────────────────────────────────────
export const portfolioApi = {
  get: () => api.get<Portfolio>("/portfolio"),
  addHolding: (data: HoldingCreate) => api.post("/portfolio/holdings", data),
  removeHolding: (id: string) => api.delete(`/portfolio/holdings/${id}`),
  setCash: (amount: number) => api.patch("/portfolio/cash", { amount }),
  sectorAllocation: () => api.get("/portfolio/sector-allocation"),
};

// ── Chat ──────────────────────────────────────────────────────────────────────
export const chatApi = {
  send: (message: string, session_id?: string) =>
    api.post<ChatResponse>("/chat", { message, session_id }),
  getHistory: (session_id: string) => api.get(`/chat/history/${session_id}`),
  getSessions: () => api.get("/chat/sessions"),
  endSession: (session_id: string) => api.post(`/chat/session/${session_id}/end`),
};

// ── Alerts ────────────────────────────────────────────────────────────────────
export const alertsApi = {
  list: (unread_only = false) => api.get<Alert[]>("/alerts", { params: { unread_only } }),
  markRead: (id: string) => api.patch(`/alerts/${id}/read`),
  markAllRead: () => api.patch("/alerts/read-all"),
  unreadCount: () => api.get<{ count: number }>("/alerts/unread-count"),
};

// ── Dashboard ─────────────────────────────────────────────────────────────────
export const dashboardApi = {
  get: () => api.get<Dashboard>("/dashboard"),
};

// ── Market ────────────────────────────────────────────────────────────────────
export const marketApi = {
  quote: (ticker: string) => api.get(`/market/quote/${ticker}`),
  quotes: (tickers: string[]) => api.get("/market/quotes", { params: { tickers: tickers.join(",") } }),
  news: (tickers: string[]) => api.get("/market/news", { params: { tickers: tickers.join(",") } }),
};

// ── Types ──────────────────────────────────────────────────────────────────────
export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  risk_tolerance: string;
  investment_horizon_years: number;
  preferred_sectors: string[];
  restricted_assets: string[];
  tax_jurisdiction: string;
  liquidity_need_pct: number;
}

export interface Holding {
  id: string;
  ticker: string;
  name: string;
  asset_class: string;
  sector: string;
  quantity: number;
  avg_cost_basis: number;
  current_price: number;
  price_change_pct: number;
  market_value: number;
  unrealized_pnl: number;
  unrealized_pnl_pct: number;
  weight: number;
}

export interface HoldingCreate {
  ticker: string;
  name?: string;
  asset_class?: string;
  sector?: string;
  geography?: string;
  quantity: number;
  avg_cost_basis: number;
}

export interface Portfolio {
  id: string;
  name: string;
  cash_balance: number;
  total_value: number;
  total_cost: number;
  total_unrealized_pnl: number;
  total_unrealized_pnl_pct: number;
  day_change: number;
  day_change_pct: number;
  holdings: Holding[];
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  timestamp?: string;
}

export interface ChatResponse {
  session_id: string;
  message_id: string;
  content: string;
  model_used: string;
  tokens_used: number;
  context_used: string[];
}

export interface Alert {
  id: string;
  severity: "info" | "warning" | "critical";
  category: string;
  title: string;
  body: string;
  ticker?: string;
  is_read: boolean;
  created_at: string;
}

export interface Dashboard {
  portfolio: Portfolio;
  unread_alerts: number;
  recent_alerts: Alert[];
  top_movers: Holding[];
  sector_allocation: Record<string, number>;
}
