/**
 * Global Zustand store — auth, portfolio, chat state.
 */
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Alert, ChatMessage, Portfolio, UserProfile } from "./api";

interface AuthState {
  token: string | null;
  userId: string | null;
  user: UserProfile | null;
  setAuth: (token: string, userId: string) => void;
  setUser: (user: UserProfile) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      userId: null,
      user: null,
      setAuth: (token, userId) => {
        if (typeof window !== "undefined") localStorage.setItem("token", token);
        set({ token, userId });
      },
      setUser: (user) => set({ user }),
      logout: () => {
        if (typeof window !== "undefined") localStorage.removeItem("token");
        set({ token: null, userId: null, user: null });
      },
    }),
    { name: "investiq-auth", partialize: (s) => ({ token: s.token, userId: s.userId }) }
  )
);

// ── Chat store ────────────────────────────────────────────────────────────────
interface ChatState {
  sessionId: string | null;
  messages: ChatMessage[];
  isTyping: boolean;
  setSessionId: (id: string) => void;
  addMessage: (msg: ChatMessage) => void;
  setTyping: (v: boolean) => void;
  clearChat: () => void;
}

export const useChatStore = create<ChatState>((set) => ({
  sessionId: null,
  messages: [],
  isTyping: false,
  setSessionId: (id) => set({ sessionId: id }),
  addMessage: (msg) => set((s) => ({ messages: [...s.messages, msg] })),
  setTyping: (v) => set({ isTyping: v }),
  clearChat: () => set({ messages: [], sessionId: null }),
}));

// ── Portfolio store ───────────────────────────────────────────────────────────
interface PortfolioState {
  portfolio: Portfolio | null;
  setPortfolio: (p: Portfolio) => void;
}

export const usePortfolioStore = create<PortfolioState>((set) => ({
  portfolio: null,
  setPortfolio: (portfolio) => set({ portfolio }),
}));

// ── Alerts store ──────────────────────────────────────────────────────────────
interface AlertState {
  alerts: Alert[];
  unreadCount: number;
  setAlerts: (alerts: Alert[]) => void;
  setUnreadCount: (n: number) => void;
  markRead: (id: string) => void;
}

export const useAlertStore = create<AlertState>((set) => ({
  alerts: [],
  unreadCount: 0,
  setAlerts: (alerts) => set({ alerts }),
  setUnreadCount: (n) => set({ unreadCount: n }),
  markRead: (id) =>
    set((s) => ({
      alerts: s.alerts.map((a) => (a.id === id ? { ...a, is_read: true } : a)),
      unreadCount: Math.max(0, s.unreadCount - 1),
    })),
}));
