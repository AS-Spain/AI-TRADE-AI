import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "InvestIQ — AI Investment Copilot",
  description: "AI-native portfolio copilot powered by GPT-4o",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-surface text-slate-100 antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
