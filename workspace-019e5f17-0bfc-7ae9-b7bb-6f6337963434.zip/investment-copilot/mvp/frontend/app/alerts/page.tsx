"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { alertsApi } from "@/lib/api";
import { useAuthStore, useAlertStore } from "@/lib/store";
import { Sidebar } from "@/components/ui/Sidebar";
import { AlertTriangle, Info, XCircle, Bell, CheckCheck } from "lucide-react";
import clsx from "clsx";
import { formatDistanceToNow } from "date-fns";

const SEVERITY = {
  info:     { icon: Info,          color: "text-blue-400",  bg: "bg-blue-400/5",  border: "border-blue-400/20" },
  warning:  { icon: AlertTriangle, color: "text-amber-400", bg: "bg-amber-400/5", border: "border-amber-400/20" },
  critical: { icon: XCircle,       color: "text-red-400",   bg: "bg-red-400/5",   border: "border-red-400/20" },
};

export default function AlertsPage() {
  const { token } = useAuthStore();
  const { setUnreadCount } = useAlertStore();
  const qc = useQueryClient();

  const { data: alerts = [] } = useQuery({
    queryKey: ["alerts"],
    queryFn: () => alertsApi.list().then((r) => r.data),
    enabled: !!token,
  });

  const markReadMutation = useMutation({
    mutationFn: (id: string) => alertsApi.markRead(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["alerts"] });
    },
  });

  const markAllMutation = useMutation({
    mutationFn: () => alertsApi.markAllRead(),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["alerts"] });
      setUnreadCount(0);
    },
  });

  const unread = alerts.filter((a: any) => !a.is_read).length;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Alerts</h1>
            <p className="text-slate-400 text-sm">{unread} unread</p>
          </div>
          {unread > 0 && (
            <button
              onClick={() => markAllMutation.mutate()}
              className="btn-ghost flex items-center gap-2 text-sm"
            >
              <CheckCheck className="w-4 h-4" /> Mark all read
            </button>
          )}
        </div>

        {alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-slate-500">
            <Bell className="w-12 h-12 mb-4 opacity-20" />
            <p className="text-lg font-medium">All clear</p>
            <p className="text-sm mt-1">No alerts for your portfolio</p>
          </div>
        ) : (
          <div className="space-y-3 max-w-2xl">
            {alerts.map((alert: any) => {
              const s = SEVERITY[alert.severity as keyof typeof SEVERITY] || SEVERITY.info;
              return (
                <div
                  key={alert.id}
                  className={clsx(
                    "card border flex gap-4 cursor-pointer hover:border-opacity-50 transition-all",
                    s.bg, s.border,
                    !alert.is_read && "ring-1 ring-brand-500/30"
                  )}
                  onClick={() => !alert.is_read && markReadMutation.mutate(alert.id)}
                >
                  <div className={`w-9 h-9 rounded-lg ${s.bg} border ${s.border} flex items-center justify-center shrink-0`}>
                    <s.icon className={`w-4 h-4 ${s.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <p className={`font-semibold text-sm ${s.color}`}>{alert.title}</p>
                      <div className="flex items-center gap-2 shrink-0">
                        {!alert.is_read && (
                          <span className="w-2 h-2 rounded-full bg-brand-500" />
                        )}
                        <span className="text-xs text-slate-500">
                          {formatDistanceToNow(new Date(alert.created_at), { addSuffix: true })}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm text-slate-400 mt-1">{alert.body}</p>
                    {alert.ticker && (
                      <span className="inline-block mt-2 text-xs bg-surface-card border border-surface-border text-slate-400 px-2 py-0.5 rounded">
                        {alert.ticker}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
