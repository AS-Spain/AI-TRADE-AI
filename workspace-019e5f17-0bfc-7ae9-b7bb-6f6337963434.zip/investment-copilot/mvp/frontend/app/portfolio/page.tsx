"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { portfolioApi } from "@/lib/api";
import { useAuthStore } from "@/lib/store";
import { Sidebar } from "@/components/ui/Sidebar";
import { SectorChart } from "@/components/charts/SectorChart";
import { HoldingsTable } from "@/components/charts/HoldingsTable";
import { Plus, Trash2, Loader2, DollarSign } from "lucide-react";
import clsx from "clsx";

interface AddForm {
  ticker: string;
  name: string;
  quantity: string;
  avg_cost_basis: string;
  sector: string;
  asset_class: string;
}

const SECTORS = [
  "Technology","Financials","Healthcare","Consumer Cyclical",
  "Consumer Defensive","Energy","Industrials","Materials",
  "Real Estate","Utilities","Communication Services","ETF",
  "Bond ETF","Commodity","Crypto","Unknown",
];

export default function PortfolioPage() {
  const router = useRouter();
  const { token } = useAuthStore();
  const qc = useQueryClient();
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState<AddForm>({
    ticker: "", name: "", quantity: "", avg_cost_basis: "",
    sector: "Technology", asset_class: "equity",
  });

  const { data: portfolio, isLoading } = useQuery({
    queryKey: ["portfolio"],
    queryFn: () => portfolioApi.get().then((r) => r.data),
    enabled: !!token,
  });

  const addMutation = useMutation({
    mutationFn: (d: any) => portfolioApi.addHolding(d),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["portfolio"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      setShowAdd(false);
      setForm({ ticker: "", name: "", quantity: "", avg_cost_basis: "", sector: "Technology", asset_class: "equity" });
    },
  });

  const removeMutation = useMutation({
    mutationFn: (id: string) => portfolioApi.removeHolding(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["portfolio"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });

  function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    addMutation.mutate({
      ticker: form.ticker.toUpperCase(),
      name: form.name,
      quantity: parseFloat(form.quantity),
      avg_cost_basis: parseFloat(form.avg_cost_basis),
      sector: form.sector,
      asset_class: form.asset_class,
    });
  }

  const sectorAlloc = portfolio
    ? Object.fromEntries(
        Object.entries(
          portfolio.holdings.reduce((acc: Record<string, number>, h: any) => {
            acc[h.sector] = (acc[h.sector] || 0) + h.market_value;
            return acc;
          }, {})
        ).map(([k, v]) => [k, portfolio.total_value ? ((v as number) / portfolio.total_value) * 100 : 0])
      )
    : {};

  if (isLoading) return (
    <div className="flex h-screen items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Portfolio</h1>
            <p className="text-slate-400 text-sm">{portfolio?.name}</p>
          </div>
          <button onClick={() => setShowAdd(true)} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" /> Add Position
          </button>
        </div>

        {/* Stats */}
        {portfolio && (
          <div className="grid grid-cols-3 gap-4">
            <div className="card">
              <p className="text-slate-400 text-xs">Total Value</p>
              <p className="text-2xl font-bold text-white mt-1">
                ${portfolio.total_value.toLocaleString("en-US", { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="card">
              <p className="text-slate-400 text-xs">Cash Balance</p>
              <p className="text-2xl font-bold text-emerald-400 mt-1 flex items-center gap-1">
                <DollarSign className="w-5 h-5" />
                {portfolio.cash_balance.toLocaleString("en-US", { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="card">
              <p className="text-slate-400 text-xs">Total P&L</p>
              <p className={clsx("text-2xl font-bold mt-1",
                portfolio.total_unrealized_pnl >= 0 ? "text-emerald-400" : "text-red-400"
              )}>
                {portfolio.total_unrealized_pnl >= 0 ? "+" : ""}
                ${Math.abs(portfolio.total_unrealized_pnl).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                <span className="text-sm ml-1">({portfolio.total_unrealized_pnl_pct.toFixed(2)}%)</span>
              </p>
            </div>
          </div>
        )}

        {/* Main content */}
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2">
            {/* Holdings with delete */}
            <div className="card">
              <h3 className="font-semibold text-sm mb-4">Holdings</h3>
              {portfolio?.holdings.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-slate-500 mb-4">No positions yet</p>
                  <button onClick={() => setShowAdd(true)} className="btn-primary">
                    Add your first position
                  </button>
                </div>
              ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-slate-500 text-xs uppercase border-b border-surface-border">
                      <th className="text-left pb-3">Ticker</th>
                      <th className="text-right pb-3">Qty</th>
                      <th className="text-right pb-3">Avg Cost</th>
                      <th className="text-right pb-3">Price</th>
                      <th className="text-right pb-3">Mkt Val</th>
                      <th className="text-right pb-3">P&L</th>
                      <th className="text-right pb-3">Weight</th>
                      <th className="pb-3"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-border/50">
                    {portfolio?.holdings.map((h: any) => (
                      <tr key={h.id} className="hover:bg-surface-border/10 transition-colors">
                        <td className="py-3">
                          <div className="font-semibold">{h.ticker}</div>
                          <div className="text-xs text-slate-500">{h.sector}</div>
                        </td>
                        <td className="text-right py-3 font-mono text-slate-300">{h.quantity}</td>
                        <td className="text-right py-3 font-mono text-slate-400">${h.avg_cost_basis.toFixed(2)}</td>
                        <td className="text-right py-3 font-mono">${h.current_price.toFixed(2)}</td>
                        <td className="text-right py-3 font-mono">${h.market_value.toLocaleString()}</td>
                        <td className={clsx("text-right py-3 font-mono text-xs",
                          h.unrealized_pnl >= 0 ? "text-emerald-400" : "text-red-400"
                        )}>
                          {h.unrealized_pnl >= 0 ? "+" : ""}{h.unrealized_pnl_pct.toFixed(1)}%
                        </td>
                        <td className="text-right py-3 text-xs text-slate-400">{h.weight.toFixed(1)}%</td>
                        <td className="text-right py-3">
                          <button
                            onClick={() => removeMutation.mutate(h.id)}
                            className="btn-ghost p-1 text-slate-600 hover:text-red-400"
                          >
                            {removeMutation.isPending ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Trash2 className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          <div>
            <SectorChart allocation={sectorAlloc} />
          </div>
        </div>
      </main>

      {/* Add Position Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="card w-full max-w-md">
            <h2 className="font-bold text-lg mb-5">Add Position</h2>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Ticker *</label>
                  <input className="input" value={form.ticker} onChange={(e) => setForm({ ...form, ticker: e.target.value.toUpperCase() })} placeholder="AAPL" required />
                </div>
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Name</label>
                  <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Apple Inc." />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Quantity *</label>
                  <input className="input" type="number" step="0.0001" min="0.0001" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} placeholder="10" required />
                </div>
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Avg Cost (USD) *</label>
                  <input className="input" type="number" step="0.01" min="0.01" value={form.avg_cost_basis} onChange={(e) => setForm({ ...form, avg_cost_basis: e.target.value })} placeholder="150.00" required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Sector</label>
                  <select className="input" value={form.sector} onChange={(e) => setForm({ ...form, sector: e.target.value })}>
                    {SECTORS.map((s) => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Asset Class</label>
                  <select className="input" value={form.asset_class} onChange={(e) => setForm({ ...form, asset_class: e.target.value })}>
                    {["equity","etf","bond","crypto","real_estate","commodity"].map((a) => <option key={a}>{a}</option>)}
                  </select>
                </div>
              </div>

              {addMutation.isError && (
                <p className="text-red-400 text-sm">{(addMutation.error as any)?.response?.data?.detail || "Error adding position"}</p>
              )}

              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowAdd(false)} className="btn-ghost flex-1">Cancel</button>
                <button type="submit" className="btn-primary flex-1 flex items-center justify-center gap-2" disabled={addMutation.isPending}>
                  {addMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                  Add Position
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
