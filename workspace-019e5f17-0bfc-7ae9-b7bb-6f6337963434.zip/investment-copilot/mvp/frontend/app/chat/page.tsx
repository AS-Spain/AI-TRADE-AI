"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore, useChatStore } from "@/lib/store";
import { chatApi } from "@/lib/api";
import { Sidebar } from "@/components/ui/Sidebar";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Send, Loader2, Bot, User, Plus, RotateCcw,
  Database, TrendingUp, BookOpen, Newspaper
} from "lucide-react";
import clsx from "clsx";
import { formatDistanceToNow } from "date-fns";

const SLOT_ICONS: Record<string, React.ReactNode> = {
  portfolio:           <TrendingUp className="w-3 h-3" />,
  live_quotes:         <TrendingUp className="w-3 h-3" />,
  market_news:         <Newspaper className="w-3 h-3" />,
  macro_indicators:    <Database className="w-3 h-3" />,
  long_term_memory:    <BookOpen className="w-3 h-3" />,
  conversation_history:<RotateCcw className="w-3 h-3" />,
};

const STARTER_PROMPTS = [
  "Analyse my portfolio's risk exposure",
  "Which of my holdings have the most upside?",
  "Should I rebalance? My tech weight feels high",
  "Explain my unrealized P&L breakdown",
  "What macro risks should I be watching?",
  "Suggest 3 ETFs to diversify my portfolio",
];

interface MessageMeta {
  context_used?: string[];
  model_used?: string;
  tokens_used?: number;
  timestamp?: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  meta?: MessageMeta;
}

export default function ChatPage() {
  const router = useRouter();
  const { token } = useAuthStore();
  const { sessionId, messages: storeMessages, setSessionId, clearChat } = useChatStore();

  const [messages, setMessages] = useState<Message[]>(storeMessages);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [streamContent, setStreamContent] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (!token) router.push("/login");
  }, [token, router]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamContent]);

  async function send(text?: string) {
    const msg = (text || input).trim();
    if (!msg || sending) return;
    setInput("");

    const userMsg: Message = {
      role: "user",
      content: msg,
      meta: { timestamp: new Date().toISOString() },
    };
    setMessages((prev) => [...prev, userMsg]);
    setSending(true);
    setIsStreaming(true);
    setStreamContent("");

    try {
      // Try streaming via SSE
      const BASE = process.env.NEXT_PUBLIC_API_URL || "";
      const token_val = localStorage.getItem("token");
      const response = await fetch(`${BASE}/api/v1/chat/stream`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token_val}`,
        },
        body: JSON.stringify({ message: msg, session_id: sessionId }),
      });

      if (!response.ok) throw new Error("stream failed");

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      let full = "";
      let newSessionId = sessionId;
      let contextUsed: string[] = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        const lines = chunk.split("\n");
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.type === "token") {
              full += data.content;
              setStreamContent(full);
            } else if (data.type === "done") {
              newSessionId = data.session_id;
              contextUsed = data.slots_used || [];
            }
          } catch (_) {}
        }
      }

      if (newSessionId && newSessionId !== sessionId) {
        setSessionId(newSessionId);
      }

      const assistantMsg: Message = {
        role: "assistant",
        content: full,
        meta: { context_used: contextUsed, timestamp: new Date().toISOString() },
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setStreamContent("");
    } catch (_) {
      // Fallback to non-streaming
      try {
        const res = await chatApi.send(msg, sessionId || undefined);
        const data = res.data;
        if (!sessionId) setSessionId(data.session_id);
        const assistantMsg: Message = {
          role: "assistant",
          content: data.content,
          meta: {
            context_used: data.context_used,
            model_used: data.model_used,
            tokens_used: data.tokens_used,
            timestamp: new Date().toISOString(),
          },
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } catch (err: any) {
        setMessages((prev) => [...prev, {
          role: "assistant",
          content: "⚠️ Sorry, something went wrong. Please try again.",
        }]);
      }
    } finally {
      setSending(false);
      setIsStreaming(false);
      inputRef.current?.focus();
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  function newChat() {
    clearChat();
    setMessages([]);
    setSessionId(null as any);
  }

  const isEmpty = messages.length === 0 && !isStreaming;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-surface-border bg-surface-card/50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-sm">AI Copilot</h1>
              <p className="text-xs text-slate-500">
                {sessionId ? `Session ${sessionId.slice(0, 8)}` : "New conversation"}
              </p>
            </div>
          </div>
          <button onClick={newChat} className="btn-ghost flex items-center gap-2 text-xs">
            <Plus className="w-3.5 h-3.5" /> New Chat
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
          {isEmpty && (
            <div className="flex flex-col items-center justify-center h-full space-y-6 pb-12">
              <div className="w-16 h-16 bg-brand-600/20 rounded-2xl flex items-center justify-center">
                <Bot className="w-8 h-8 text-brand-400" />
              </div>
              <div className="text-center">
                <h2 className="text-xl font-bold mb-2">How can I help you today?</h2>
                <p className="text-slate-400 text-sm max-w-sm">
                  Ask me anything about your portfolio — risk, performance, news, or strategy.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3 max-w-lg w-full">
                {STARTER_PROMPTS.map((p) => (
                  <button
                    key={p}
                    onClick={() => send(p)}
                    className="text-left text-sm px-4 py-3 rounded-lg bg-surface-card border border-surface-border
                               hover:border-brand-500/50 hover:bg-brand-600/5 transition-all text-slate-300 hover:text-white"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <MessageBubble key={i} message={msg} />
          ))}

          {isStreaming && streamContent && (
            <MessageBubble
              message={{ role: "assistant", content: streamContent }}
              streaming
            />
          )}
          {sending && !isStreaming && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="card flex items-center gap-2 py-3">
                <Loader2 className="w-4 h-4 animate-spin text-brand-400" />
                <span className="text-sm text-slate-400">Analysing your portfolio…</span>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="px-6 pb-6 pt-3 border-t border-surface-border">
          <div className="flex gap-3 items-end bg-surface-card border border-surface-border rounded-xl p-3">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask about your portfolio, risk, market events…"
              className="flex-1 bg-transparent text-sm text-slate-100 placeholder:text-slate-500 resize-none focus:outline-none min-h-[40px] max-h-[120px]"
              rows={1}
              disabled={sending}
            />
            <button
              onClick={() => send()}
              disabled={!input.trim() || sending}
              className="btn-primary p-2 rounded-lg shrink-0"
            >
              {sending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </button>
          </div>
          <p className="text-xs text-slate-600 text-center mt-2">
            AI-assisted analysis · Not financial advice · Portfolio data is real-time
          </p>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ message, streaming }: { message: Message; streaming?: boolean }) {
  const isUser = message.role === "user";

  return (
    <div className={clsx("flex gap-3 items-start", isUser && "flex-row-reverse")}>
      <div className={clsx(
        "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
        isUser ? "bg-slate-700" : "bg-brand-600"
      )}>
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-white" />}
      </div>

      <div className={clsx("max-w-[75%] space-y-2", isUser && "items-end flex flex-col")}>
        <div className={clsx(
          "rounded-xl px-4 py-3 text-sm",
          isUser
            ? "bg-brand-600 text-white rounded-tr-sm"
            : "bg-surface-card border border-surface-border text-slate-100 rounded-tl-sm"
        )}>
          {isUser ? (
            <p>{message.content}</p>
          ) : (
            <div className="prose prose-invert prose-sm max-w-none
                            prose-p:my-1 prose-ul:my-1 prose-ol:my-1
                            prose-li:my-0.5 prose-headings:my-2
                            prose-code:bg-surface prose-code:px-1 prose-code:rounded
                            prose-strong:text-white">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {message.content}
              </ReactMarkdown>
              {streaming && (
                <span className="inline-block w-1.5 h-4 bg-brand-400 animate-pulse ml-0.5 rounded-sm" />
              )}
            </div>
          )}
        </div>

        {/* Context pills */}
        {!isUser && message.meta?.context_used && message.meta.context_used.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {message.meta.context_used.map((slot) => (
              <span
                key={slot}
                className="flex items-center gap-1 text-xs bg-surface-card border border-surface-border
                           text-slate-500 px-2 py-0.5 rounded-full"
              >
                {SLOT_ICONS[slot] || <Database className="w-3 h-3" />}
                {slot.replace(/_/g, " ")}
              </span>
            ))}
          </div>
        )}

        {message.meta?.timestamp && (
          <p className="text-xs text-slate-600">
            {formatDistanceToNow(new Date(message.meta.timestamp), { addSuffix: true })}
            {message.meta.model_used && ` · ${message.meta.model_used}`}
            {message.meta.tokens_used ? ` · ${message.meta.tokens_used} tokens` : ""}
          </p>
        )}
      </div>
    </div>
  );
}
