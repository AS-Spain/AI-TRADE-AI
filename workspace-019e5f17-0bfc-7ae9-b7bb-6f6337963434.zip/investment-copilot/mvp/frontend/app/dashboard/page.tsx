"use client";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { dashboardApi } from "@/lib/api";
import { useAuthStore, useAlertStore } from "@/lib/store";
import { Sidebar } from "@/components/ui/Sidebar";
import { PortfolioSummaryCard } from "@/components/charts/PortfolioSummaryCard";
import { SectorChart } from "@/components/charts/SectorChart";
import { HoldingsTable } from "@/components/charts/HoldingsTable";
import { AlertsFeed } from "@/components/ui/AlertsFeed";
import { TopMovers } from "@/components/ui/TopMovers";
import { QuickChat } from "@/components/ui/QuickChat";
import { Loader2, RefreshCw } from "lucide-react";

export default function DashboardPage() {
  const router = useRouter();
  const { token } = useAuthStore();
  const { setAlerts, setUnreadCount } = useAlertStore();

  useEffect(() => {
    if (!token) router.push("/login");
  }, [token, router]);

  const { data, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => dashboardApi.get().then((r) => r.data),
    refetchInterval: 60_000,  // auto-refresh every 60s
    enabled: !!token,
  });

  useEffect(() => {
    if (data) {
      setAlerts(data.recent_alerts);
      setUnreadCount(data.unread_alerts);
    }
  }, [data, setAlerts, setUnreadCount]);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
      </div>
    );
  }

  const { portfolio, sector_allocation, top_movers, recent_alerts, unread_alerts } = data!;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <p className="text-slate-400 text-sm mt-0.5">
              {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
            </p>
          </div>
          <button
            onClick={() => refetch()}
            className="btn-ghost flex items-center gap-2 text-sm"
            disabled={isRefetching}
          >
            <RefreshCw className={`w-4 h-4 ${isRefetching ? "animate-spin" : ""}`} />
            Refresh
          </button>
        </div>

        {/* Portfolio Summary Row */}
        <PortfolioSummaryCard portfolio={portfolio} />

        {/* Middle Row */}
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2">
            <HoldingsTable holdings={portfolio.holdings} totalValue={portfolio.total_value} />
          </div>
          <div className="space-y-6">
            <SectorChart allocation={sector_allocation} />
            <TopMovers movers={top_movers} />
          </div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-2 gap-6">
          <AlertsFeed alerts={recent_alerts} unread={unread_alerts} />
          <QuickChat />
        </div>
      </main>
    </div>
  );
}
