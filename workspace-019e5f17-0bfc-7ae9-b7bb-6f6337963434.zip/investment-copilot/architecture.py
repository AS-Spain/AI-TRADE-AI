"""
=============================================================================
  AI-NATIVE INVESTMENT COPILOT — CORE ARCHITECTURE
  Full Python skeleton with docstrings, interfaces, and logic stubs.
=============================================================================

MODULES
  1. ai_reasoning        — LLM orchestration, multi-model routing, chain-of-thought
  2. memory              — Short-term (session) + Long-term (vector + relational)
  3. context_injection   — Dynamic prompt construction & context assembly
  4. portfolio_analysis  — Holdings, risk, exposure, performance analytics
  5. recommendation      — Ranked, explainable investment recommendations
  6. alert_system        — Proactive, event-driven alert pipeline
"""

from __future__ import annotations

import hashlib
import json
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable, Generator, Literal, Optional


# ─────────────────────────────────────────────────────────────────────────────
# SHARED TYPES & ENUMS
# ─────────────────────────────────────────────────────────────────────────────

class ModelProvider(Enum):
    OPENAI  = "openai"
    CLAUDE  = "anthropic"
    GEMINI  = "google"

class RiskTolerance(Enum):
    CONSERVATIVE  = "conservative"
    MODERATE      = "moderate"
    AGGRESSIVE    = "aggressive"

class AlertSeverity(Enum):
    INFO     = "info"
    WARNING  = "warning"
    CRITICAL = "critical"

class RecommendationType(Enum):
    BUY    = "buy"
    SELL   = "sell"
    HOLD   = "hold"
    HEDGE  = "hedge"
    REBALANCE = "rebalance"

@dataclass
class UserProfile:
    user_id:        str
    risk_tolerance: RiskTolerance
    investment_horizon_years: int
    preferred_sectors: list[str]
    restricted_assets: list[str]        # ESG exclusions, regulatory, personal
    tax_jurisdiction: str
    liquidity_need_pct: float           # % of portfolio that must stay liquid


# ─────────────────────────────────────────────────────────────────────────────
# 1. AI REASONING SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

class ReasoningMode(Enum):
    """Controls the depth vs. cost tradeoff of the reasoning pipeline."""
    FAST       = "fast"        # Single pass, low latency  (GPT-4o-mini / Gemini Flash)
    STANDARD   = "standard"   # Single pass, best model   (GPT-4o / Claude Sonnet)
    DEEP       = "deep"       # Multi-step CoT             (o3 / Claude Opus)
    ENSEMBLE   = "ensemble"   # Multi-model voting         (all providers)

@dataclass
class ReasoningRequest:
    query:          str
    mode:           ReasoningMode
    injected_context: dict[str, Any]    # built by ContextInjector
    user_profile:   UserProfile
    session_id:     str
    stream:         bool = False

@dataclass
class ReasoningResponse:
    answer:         str
    reasoning_trace: list[str]          # chain-of-thought steps
    confidence:     float               # 0–1, model self-reported
    sources_used:   list[str]           # context chunks cited
    model_used:     str
    latency_ms:     int
    tokens_used:    int

class ModelRouter:
    """
    Routes requests to the correct LLM provider and model based on:
      - reasoning mode
      - query complexity (token estimate)
      - provider health / rate-limit status
      - cost budget
    """

    ROUTING_TABLE: dict[ReasoningMode, list[tuple[ModelProvider, str]]] = {
        ReasoningMode.FAST:     [(ModelProvider.OPENAI,  "gpt-4o-mini"),
                                 (ModelProvider.GEMINI,  "gemini-2.0-flash")],
        ReasoningMode.STANDARD: [(ModelProvider.OPENAI,  "gpt-4o"),
                                 (ModelProvider.CLAUDE,  "claude-sonnet-4-5")],
        ReasoningMode.DEEP:     [(ModelProvider.OPENAI,  "o3"),
                                 (ModelProvider.CLAUDE,  "claude-opus-4-5")],
        ReasoningMode.ENSEMBLE: [(ModelProvider.OPENAI,  "gpt-4o"),
                                 (ModelProvider.CLAUDE,  "claude-sonnet-4-5"),
                                 (ModelProvider.GEMINI,  "gemini-2.0-pro")],
    }

    def __init__(self, api_keys: dict[ModelProvider, str]):
        self.api_keys     = api_keys
        self._health: dict[ModelProvider, bool] = {p: True for p in ModelProvider}

    def select_model(self, mode: ReasoningMode) -> tuple[ModelProvider, str]:
        """Pick the first healthy provider for the mode."""
        for provider, model in self.ROUTING_TABLE[mode]:
            if self._health.get(provider, False):
                return provider, model
        raise RuntimeError("No healthy LLM provider available.")

    def mark_unhealthy(self, provider: ModelProvider, ttl_seconds: int = 60):
        """Temporarily mark a provider as degraded (circuit-breaker)."""
        self._health[provider] = False
        # In production: schedule re-enable after ttl_seconds via async task

    # ── provider-specific call stubs ──────────────────────────────────────

    def _call_openai(self, model: str, messages: list[dict],
                     stream: bool, api_key: str) -> dict:
        """
        POST https://api.openai.com/v1/chat/completions
        Returns raw API response dict.
        """
        raise NotImplementedError("Wire up openai SDK here.")

    def _call_claude(self, model: str, messages: list[dict],
                     stream: bool, api_key: str) -> dict:
        """
        POST https://api.anthropic.com/v1/messages
        Returns raw API response dict.
        """
        raise NotImplementedError("Wire up anthropic SDK here.")

    def _call_gemini(self, model: str, messages: list[dict],
                     stream: bool, api_key: str) -> dict:
        """
        POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
        Returns raw API response dict.
        """
        raise NotImplementedError("Wire up google-generativeai SDK here.")


class ChainOfThoughtOrchestrator:
    """
    Implements a multi-step reasoning pipeline for DEEP and ENSEMBLE modes.

    DEEP mode pipeline:
      Step 1 — Decompose:    Break query into sub-questions
      Step 2 — Retrieve:     Pull relevant context for each sub-question
      Step 3 — Reason:       Answer each sub-question with citations
      Step 4 — Synthesize:   Combine answers into final response
      Step 5 — Critique:     Self-critique and flag uncertainty

    ENSEMBLE mode:
      — Runs STANDARD on all three providers in parallel
      — Aggregates using weighted majority voting on structured fields
      — Falls back to the highest-confidence single answer for free text
    """

    def __init__(self, router: ModelRouter, memory: "MemorySystem",
                 context_injector: "ContextInjector"):
        self.router   = router
        self.memory   = memory
        self.injector = context_injector

    def run(self, request: ReasoningRequest) -> ReasoningResponse:
        if request.mode == ReasoningMode.DEEP:
            return self._deep_chain(request)
        elif request.mode == ReasoningMode.ENSEMBLE:
            return self._ensemble(request)
        else:
            return self._single_pass(request)

    def _single_pass(self, request: ReasoningRequest) -> ReasoningResponse:
        provider, model = self.router.select_model(request.mode)
        system_prompt   = self._build_system_prompt(request.user_profile)
        messages        = self._build_messages(request, system_prompt)
        # raw = self.router._call_{provider.value}(model, messages, ...)
        # parse raw → ReasoningResponse
        raise NotImplementedError

    def _deep_chain(self, request: ReasoningRequest) -> ReasoningResponse:
        steps = []
        # 1. Decompose
        sub_questions = self._decompose(request.query, request)
        steps.append(f"Decomposed into {len(sub_questions)} sub-questions")
        # 2-3. Retrieve + Reason per sub-question
        sub_answers = []
        for sq in sub_questions:
            ctx  = self.injector.build(sq, request.user_profile, request.session_id)
            ans  = self._answer_sub_question(sq, ctx, request)
            sub_answers.append(ans)
        steps.append("Sub-questions answered")
        # 4. Synthesize
        synthesis = self._synthesize(sub_answers, request)
        steps.append("Synthesis complete")
        # 5. Critique
        critique  = self._critique(synthesis, request)
        steps.append(f"Critique: {critique}")
        raise NotImplementedError("Wire _decompose/_answer_sub_question/_synthesize/_critique")

    def _ensemble(self, request: ReasoningRequest) -> ReasoningResponse:
        # Run in parallel across providers, then vote
        raise NotImplementedError

    def _build_system_prompt(self, profile: UserProfile) -> str:
        return f"""You are an expert investment copilot.
User risk tolerance: {profile.risk_tolerance.value}.
Investment horizon: {profile.investment_horizon_years} years.
Preferred sectors: {', '.join(profile.preferred_sectors)}.
Restricted assets: {', '.join(profile.restricted_assets)}.
Tax jurisdiction: {profile.tax_jurisdiction}.
Always cite data sources. Flag uncertainty explicitly.
Never provide unqualified financial advice — always note this is AI-assisted analysis."""

    def _build_messages(self, request: ReasoningRequest,
                         system_prompt: str) -> list[dict]:
        context_block = json.dumps(request.injected_context, indent=2)
        return [
            {"role": "system",    "content": system_prompt},
            {"role": "user",      "content": (
                f"<context>\n{context_block}\n</context>\n\n"
                f"<query>\n{request.query}\n</query>"
            )},
        ]

    # stubs
    def _decompose(self, query: str, request: ReasoningRequest) -> list[str]: ...
    def _answer_sub_question(self, q: str, ctx: dict, request: ReasoningRequest) -> str: ...
    def _synthesize(self, answers: list[str], request: ReasoningRequest) -> str: ...
    def _critique(self, answer: str, request: ReasoningRequest) -> str: ...


class AIReasoningSystem:
    """
    Top-level entry point for all LLM reasoning.
    Handles: routing → context injection → CoT → response parsing → memory write-back.
    """

    def __init__(self, router: ModelRouter, orchestrator: ChainOfThoughtOrchestrator,
                 memory: "MemorySystem", injector: "ContextInjector"):
        self.router       = router
        self.orchestrator = orchestrator
        self.memory       = memory
        self.injector     = injector

    def query(self, user_query: str, user_profile: UserProfile,
              session_id: str, mode: ReasoningMode = ReasoningMode.STANDARD,
              stream: bool = False) -> ReasoningResponse:
        """
        Full pipeline:
          1. Build injected context
          2. Construct ReasoningRequest
          3. Orchestrate reasoning
          4. Write result to short-term memory
          5. Return response
        """
        context = self.injector.build(user_query, user_profile, session_id)
        request = ReasoningRequest(
            query=user_query, mode=mode,
            injected_context=context,
            user_profile=user_profile,
            session_id=session_id,
            stream=stream,
        )
        response = self.orchestrator.run(request)
        # Write interaction to short-term memory
        self.memory.short_term.append(session_id, {
            "role": "assistant", "content": response.answer,
            "metadata": {
                "confidence": response.confidence,
                "model": response.model_used,
                "sources": response.sources_used,
            }
        })
        return response


# ─────────────────────────────────────────────────────────────────────────────
# 2. MEMORY ARCHITECTURE
# ─────────────────────────────────────────────────────────────────────────────

# ── 2a. Short-Term Memory (Session / Working Memory) ─────────────────────────

@dataclass
class Message:
    role:      Literal["user", "assistant", "system", "tool"]
    content:   str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata:  dict     = field(default_factory=dict)

class ShortTermMemory:
    """
    Maintains a sliding-window conversation buffer per session.

    Storage:   Redis (in production), dict (dev)
    TTL:       Session-scoped, typically 2 hours of inactivity
    Truncation: Token-count-aware sliding window (keeps last N tokens)
    """

    MAX_TOKENS = 8_000   # reserve head-room for system prompt + context

    def __init__(self, backend: Any = None):
        self._store: dict[str, list[Message]] = {}   # session_id → messages
        self.backend = backend  # redis client or None

    def append(self, session_id: str, message: dict) -> None:
        if session_id not in self._store:
            self._store[session_id] = []
        self._store[session_id].append(Message(**message))
        self._truncate(session_id)

    def get(self, session_id: str) -> list[Message]:
        return self._store.get(session_id, [])

    def clear(self, session_id: str) -> None:
        self._store.pop(session_id, None)

    def to_llm_messages(self, session_id: str) -> list[dict]:
        """Convert stored messages to OpenAI-compatible message list."""
        return [
            {"role": m.role, "content": m.content}
            for m in self.get(session_id)
        ]

    def _truncate(self, session_id: str) -> None:
        """
        Naïve token approximation: 1 token ≈ 4 chars.
        Drops oldest messages until under MAX_TOKENS.
        In production: use tiktoken for exact counts.
        """
        msgs = self._store[session_id]
        total_chars = sum(len(m.content) for m in msgs)
        while total_chars > self.MAX_TOKENS * 4 and len(msgs) > 2:
            removed = msgs.pop(0)
            total_chars -= len(removed.content)


# ── 2b. Long-Term Memory (Vector + Relational) ───────────────────────────────

@dataclass
class MemoryChunk:
    chunk_id:   str
    user_id:    str
    content:    str                     # raw text
    embedding:  list[float]            # from embedding API
    chunk_type: str                     # "insight" | "preference" | "decision" | "fact"
    tags:       list[str]
    created_at: datetime
    expires_at: Optional[datetime]      # None = permanent
    importance: float                   # 0–1, used for eviction scoring

class VectorStore(ABC):
    """Interface for any vector database backend (Pinecone, Weaviate, pgvector, etc.)"""

    @abstractmethod
    def upsert(self, chunks: list[MemoryChunk]) -> None: ...

    @abstractmethod
    def query(self, embedding: list[float], top_k: int,
              filters: dict) -> list[MemoryChunk]: ...

    @abstractmethod
    def delete(self, chunk_ids: list[str]) -> None: ...

class RelationalStore(ABC):
    """
    Stores structured user data:
      - Portfolio snapshots
      - Trade history
      - User preferences & goals
      - Alert history
      - Recommendation history
    """

    @abstractmethod
    def save_portfolio_snapshot(self, user_id: str, snapshot: dict) -> None: ...

    @abstractmethod
    def get_portfolio_history(self, user_id: str,
                               days: int) -> list[dict]: ...

    @abstractmethod
    def save_recommendation(self, user_id: str, rec: "Recommendation") -> None: ...

    @abstractmethod
    def get_past_recommendations(self, user_id: str,
                                  limit: int) -> list["Recommendation"]: ...

class EmbeddingService:
    """Calls an embedding API to produce dense vectors."""

    def __init__(self, provider: ModelProvider, api_key: str,
                 model: str = "text-embedding-3-large"):
        self.provider = provider
        self.api_key  = api_key
        self.model    = model

    def embed(self, texts: list[str]) -> list[list[float]]:
        """
        POST https://api.openai.com/v1/embeddings
        Returns list of 3072-dim float vectors (text-embedding-3-large).
        """
        raise NotImplementedError("Wire up embeddings API here.")

class LongTermMemory:
    """
    Manages semantic and relational long-term memory.

    Write path:  After each session, key insights are extracted by LLM,
                 embedded, and stored in VectorStore.
    Read path:   ContextInjector queries VectorStore by semantic similarity
                 to the current user query.
    Eviction:    Scored by importance × recency; low-score chunks expire.
    """

    def __init__(self, vector_store: VectorStore, relational: RelationalStore,
                 embedding_svc: EmbeddingService, extractor_llm: ModelRouter):
        self.vectors    = vector_store
        self.relational = relational
        self.embed_svc  = embedding_svc
        self.extractor  = extractor_llm

    def ingest_session(self, session_id: str, user_id: str,
                        messages: list[Message]) -> None:
        """
        Called at session end. Extracts and stores durable insights.
        Pipeline:
          1. Compress conversation to key insights via LLM
          2. Classify each insight (preference / decision / fact / risk-signal)
          3. Embed insights
          4. Upsert to VectorStore with metadata
        """
        insights = self._extract_insights(messages)
        chunks   = []
        for ins in insights:
            emb = self.embed_svc.embed([ins["text"]])[0]
            chunks.append(MemoryChunk(
                chunk_id   = str(uuid.uuid4()),
                user_id    = user_id,
                content    = ins["text"],
                embedding  = emb,
                chunk_type = ins["type"],
                tags       = ins.get("tags", []),
                created_at = datetime.utcnow(),
                expires_at = None,
                importance = ins.get("importance", 0.5),
            ))
        self.vectors.upsert(chunks)

    def recall(self, query: str, user_id: str,
               top_k: int = 5, chunk_types: list[str] = None) -> list[MemoryChunk]:
        """Semantic search over the user's long-term memory."""
        emb     = self.embed_svc.embed([query])[0]
        filters = {"user_id": user_id}
        if chunk_types:
            filters["chunk_type"] = {"$in": chunk_types}
        return self.vectors.query(emb, top_k=top_k, filters=filters)

    def _extract_insights(self, messages: list[Message]) -> list[dict]:
        """LLM call to summarise session into structured memory items."""
        raise NotImplementedError


class MemorySystem:
    """Unified memory facade used by other modules."""

    def __init__(self, short_term: ShortTermMemory, long_term: LongTermMemory):
        self.short_term = short_term
        self.long_term  = long_term


# ─────────────────────────────────────────────────────────────────────────────
# 3. CONTEXT INJECTION SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ContextSlot:
    """A named, prioritised slot in the prompt context window."""
    name:       str
    content:    Any
    priority:   int     # lower = more important (kept under compression)
    max_tokens: int     # soft cap for this slot

class MarketDataFetcher:
    """
    Fetches real-time and historical market data from external APIs.
    Supported sources: Alpha Vantage, Polygon.io, Yahoo Finance, Bloomberg API.
    """

    def get_quote(self, ticker: str) -> dict: ...
    def get_news(self, tickers: list[str], hours: int = 24) -> list[dict]: ...
    def get_macro_indicators(self) -> dict: ...       # CPI, rates, VIX, etc.
    def get_earnings_calendar(self, tickers: list[str]) -> list[dict]: ...
    def get_analyst_ratings(self, ticker: str) -> list[dict]: ...
    def get_sec_filings(self, ticker: str, form: str = "10-K") -> dict: ...

class ContextInjector:
    """
    Assembles the rich context block injected into every LLM prompt.

    Slots (in priority order):
      1. User profile + goals
      2. Current portfolio state
      3. Long-term memory recall (semantic)
      4. Short-term conversation history
      5. Live market data (quotes, macro)
      6. Recent news + sentiment
      7. Earnings / events calendar
      8. Analyst ratings
      9. Past recommendations & outcomes

    Token budget management:
      Total budget = model_context_limit − system_prompt − query − response_reserve
      Slots are filled in priority order; lower-priority slots are compressed or dropped.
    """

    TOKEN_BUDGET       = 12_000
    RESPONSE_RESERVE   = 2_000

    def __init__(self, memory: MemorySystem, market_data: MarketDataFetcher,
                 portfolio_analyzer: "PortfolioAnalyzer",
                 relational: RelationalStore):
        self.memory    = memory
        self.market    = market_data
        self.analyzer  = portfolio_analyzer
        self.relational = relational

    def build(self, query: str, profile: UserProfile,
              session_id: str) -> dict[str, Any]:
        """
        Returns a structured context dict. The orchestrator serialises this
        as a <context> XML block in the prompt.
        """
        portfolio_state = self.analyzer.current_state(profile.user_id)
        tickers         = [h["ticker"] for h in portfolio_state.get("holdings", [])]

        slots: list[ContextSlot] = [
            ContextSlot("user_profile",    self._fmt_profile(profile),              1, 500),
            ContextSlot("portfolio",       portfolio_state,                          2, 2000),
            ContextSlot("memory_recall",   self._recall(query, profile.user_id),    3, 1500),
            ContextSlot("conversation",    self._conversation(session_id),           4, 1000),
            ContextSlot("market_quotes",   self._quotes(tickers),                   5, 1500),
            ContextSlot("macro",           self.market.get_macro_indicators(),       6, 500),
            ContextSlot("news",            self.market.get_news(tickers),            7, 1500),
            ContextSlot("earnings",        self.market.get_earnings_calendar(tickers), 8, 500),
            ContextSlot("analyst_ratings", self._ratings(tickers),                  9, 500),
            ContextSlot("past_recs",       self._past_recs(profile.user_id),        10, 500),
        ]

        return self._pack(slots)

    def _pack(self, slots: list[ContextSlot]) -> dict:
        """
        Greedy token-budget packing.
        In production: use tiktoken; here we approximate 1 token ≈ 4 chars.
        """
        budget  = self.TOKEN_BUDGET - self.RESPONSE_RESERVE
        result  = {}
        used    = 0
        for slot in sorted(slots, key=lambda s: s.priority):
            serialised = json.dumps(slot.content) if not isinstance(slot.content, str) \
                         else slot.content
            tokens     = len(serialised) // 4
            if used + tokens <= budget:
                result[slot.name] = slot.content
                used += tokens
            else:
                # Try compressed version
                compressed = self._compress(serialised, budget - used)
                if compressed:
                    result[slot.name] = compressed
                    used += len(compressed) // 4
        return result

    def _compress(self, text: str, token_budget: int) -> Optional[str]:
        """Truncate to budget; in production use LLM-based summarisation."""
        char_limit = token_budget * 4
        if len(text) <= char_limit:
            return text
        return text[:char_limit] + "… [truncated]"

    def _fmt_profile(self, p: UserProfile) -> dict:
        return {
            "risk_tolerance":      p.risk_tolerance.value,
            "horizon_years":       p.investment_horizon_years,
            "preferred_sectors":   p.preferred_sectors,
            "restricted_assets":   p.restricted_assets,
            "tax_jurisdiction":    p.tax_jurisdiction,
            "liquidity_need_pct":  p.liquidity_need_pct,
        }

    def _recall(self, query: str, user_id: str) -> list[str]:
        chunks = self.memory.long_term.recall(query, user_id, top_k=5)
        return [c.content for c in chunks]

    def _conversation(self, session_id: str) -> list[dict]:
        return self.memory.short_term.to_llm_messages(session_id)[-10:]  # last 10 turns

    def _quotes(self, tickers: list[str]) -> dict:
        return {t: self.market.get_quote(t) for t in tickers}

    def _ratings(self, tickers: list[str]) -> dict:
        return {t: self.market.get_analyst_ratings(t) for t in tickers}

    def _past_recs(self, user_id: str) -> list[dict]:
        recs = self.relational.get_past_recommendations(user_id, limit=5)
        return [{"ticker": r.ticker, "type": r.rec_type.value,
                 "rationale": r.rationale, "outcome": r.outcome}
                for r in recs]


# ─────────────────────────────────────────────────────────────────────────────
# 4. PORTFOLIO ANALYSIS LOGIC
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Holding:
    ticker:          str
    asset_class:     str            # equity / bond / etf / crypto / real_estate
    quantity:        float
    avg_cost_basis:  float
    current_price:   float
    sector:          str
    geography:       str
    currency:        str

@dataclass
class PortfolioSnapshot:
    user_id:         str
    timestamp:       datetime
    holdings:        list[Holding]
    cash_balance:    float
    total_value:     float

    @property
    def weights(self) -> dict[str, float]:
        return {h.ticker: (h.quantity * h.current_price) / self.total_value
                for h in self.holdings}

class RiskEngine:
    """
    Computes quantitative risk metrics from historical price data.
    Data sourced from market data API (e.g. Polygon.io).
    """

    def portfolio_volatility(self, weights: dict[str, float],
                              returns_df: Any) -> float:
        """Annualised portfolio σ using covariance matrix."""
        raise NotImplementedError

    def var(self, snapshot: PortfolioSnapshot, confidence: float = 0.95,
             horizon_days: int = 1) -> float:
        """Parametric Value-at-Risk (USD)."""
        raise NotImplementedError

    def cvar(self, snapshot: PortfolioSnapshot, confidence: float = 0.95,
              horizon_days: int = 1) -> float:
        """Conditional VaR / Expected Shortfall."""
        raise NotImplementedError

    def beta(self, ticker: str, benchmark: str = "SPY") -> float:
        """Market beta relative to benchmark."""
        raise NotImplementedError

    def sharpe(self, returns: list[float], risk_free_rate: float = 0.045) -> float:
        raise NotImplementedError

    def sortino(self, returns: list[float], risk_free_rate: float = 0.045) -> float:
        raise NotImplementedError

    def max_drawdown(self, returns: list[float]) -> float:
        raise NotImplementedError

class ExposureAnalyzer:
    """Breaks down portfolio exposure across multiple dimensions."""

    def sector_exposure(self, snapshot: PortfolioSnapshot) -> dict[str, float]:
        exposure: dict[str, float] = {}
        for h in snapshot.holdings:
            w = (h.quantity * h.current_price) / snapshot.total_value
            exposure[h.sector] = exposure.get(h.sector, 0.0) + w
        return exposure

    def geography_exposure(self, snapshot: PortfolioSnapshot) -> dict[str, float]:
        raise NotImplementedError

    def asset_class_exposure(self, snapshot: PortfolioSnapshot) -> dict[str, float]:
        raise NotImplementedError

    def currency_exposure(self, snapshot: PortfolioSnapshot) -> dict[str, float]:
        raise NotImplementedError

    def concentration_risk(self, snapshot: PortfolioSnapshot) -> dict:
        """
        Returns Herfindahl-Hirschman Index (HHI) per dimension.
        HHI > 0.25 → concentrated.
        """
        weights = list(snapshot.weights.values())
        hhi     = sum(w ** 2 for w in weights)
        top5    = sorted(weights, reverse=True)[:5]
        return {"hhi": hhi, "top5_weight": sum(top5)}

    def factor_exposure(self, snapshot: PortfolioSnapshot) -> dict[str, float]:
        """
        Fama-French 5-factor exposure:
          Mkt-RF, SMB, HML, RMW, CMA
        Requires factor return data from Ken French data library or provider API.
        """
        raise NotImplementedError

class TaxAnalyzer:
    """
    Tax-aware analysis. Rules are jurisdiction-specific; designed for extensibility.
    """

    def harvest_candidates(self, snapshot: PortfolioSnapshot,
                            threshold_loss_pct: float = -0.05) -> list[Holding]:
        """Identify positions with unrealised losses eligible for tax-loss harvesting."""
        candidates = []
        for h in snapshot.holdings:
            unrealised_pct = (h.current_price - h.avg_cost_basis) / h.avg_cost_basis
            if unrealised_pct < threshold_loss_pct:
                candidates.append(h)
        return candidates

    def capital_gains_estimate(self, holding: Holding,
                                sale_price: float, jurisdiction: str) -> dict:
        """Estimate short-term vs. long-term capital gains tax for a hypothetical sale."""
        raise NotImplementedError

class PortfolioAnalyzer:
    """Facade for all portfolio analytics. Called by ContextInjector and RecommendationEngine."""

    def __init__(self, relational: RelationalStore, market_data: MarketDataFetcher,
                 risk_engine: RiskEngine, exposure: ExposureAnalyzer,
                 tax: TaxAnalyzer):
        self.relational = relational
        self.market     = market_data
        self.risk       = risk_engine
        self.exposure   = exposure
        self.tax        = tax

    def current_state(self, user_id: str) -> dict:
        """
        Returns a rich JSON-serialisable snapshot of the portfolio:
          - holdings with live prices
          - performance vs. benchmark
          - risk metrics
          - exposure breakdown
          - tax-loss harvest candidates
        """
        snapshot      = self._load_snapshot(user_id)
        returns_df    = None  # load from market API
        sector_exp    = self.exposure.sector_exposure(snapshot)
        geo_exp       = self.exposure.geography_exposure(snapshot)
        concentration = self.exposure.concentration_risk(snapshot)
        vol           = self.risk.portfolio_volatility(snapshot.weights, returns_df)
        var_1d        = self.risk.var(snapshot)
        harvest       = self.tax.harvest_candidates(snapshot)

        return {
            "total_value":   snapshot.total_value,
            "cash_pct":      snapshot.cash_balance / snapshot.total_value,
            "holdings":      [self._fmt_holding(h, snapshot.total_value)
                              for h in snapshot.holdings],
            "exposure": {
                "sector":      sector_exp,
                "geography":   geo_exp,
                "concentration": concentration,
            },
            "risk": {
                "annualised_volatility": vol,
                "var_1d_95":             var_1d,
            },
            "tax_harvest_candidates": [h.ticker for h in harvest],
        }

    def _load_snapshot(self, user_id: str) -> PortfolioSnapshot:
        """Load latest snapshot from relational store, refresh prices from market API."""
        raise NotImplementedError

    def _fmt_holding(self, h: Holding, total_value: float) -> dict:
        mv       = h.quantity * h.current_price
        pnl_pct  = (h.current_price - h.avg_cost_basis) / h.avg_cost_basis
        return {
            "ticker":    h.ticker,
            "weight":    mv / total_value,
            "mv":        mv,
            "pnl_pct":   pnl_pct,
            "sector":    h.sector,
            "geography": h.geography,
        }


# ─────────────────────────────────────────────────────────────────────────────
# 5. RECOMMENDATION ENGINE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Recommendation:
    rec_id:     str
    user_id:    str
    ticker:     str
    rec_type:   RecommendationType
    rationale:  str                     # LLM-generated, cited
    confidence: float                   # 0–1
    supporting_data: dict               # quant signals, news, analyst views
    risk_factors:    list[str]          # explicit risk disclosures
    time_horizon:    str                # "short" | "medium" | "long"
    created_at:  datetime
    outcome:     Optional[str] = None   # filled in later for learning loop

class SignalAggregator:
    """
    Aggregates quantitative and qualitative signals for a ticker.
    Each signal carries a weight; the weighted score drives recommendation strength.
    """

    SIGNAL_WEIGHTS = {
        "momentum_1m":        0.10,
        "momentum_3m":        0.10,
        "mean_reversion":     0.08,
        "analyst_consensus":  0.15,
        "earnings_surprise":  0.12,
        "insider_activity":   0.08,
        "news_sentiment":     0.12,
        "macro_alignment":    0.10,
        "valuation_z_score":  0.10,
        "technical_pattern":  0.05,
    }

    def compute(self, ticker: str, market_data: MarketDataFetcher,
                portfolio_snapshot: PortfolioSnapshot,
                profile: UserProfile) -> dict[str, float]:
        """
        Returns dict of signal_name → score (–1 to +1).
        Positive = bullish / buy signal; Negative = bearish / sell signal.
        """
        signals = {}
        # Each signal calls relevant market_data methods and applies logic
        # signals["momentum_1m"]       = self._momentum(ticker, 21, market_data)
        # signals["analyst_consensus"] = self._analyst(ticker, market_data)
        # signals["news_sentiment"]    = self._sentiment(ticker, market_data)
        # ... etc.
        raise NotImplementedError

    def weighted_score(self, signals: dict[str, float]) -> float:
        """Weighted sum of signals → aggregate score in [–1, +1]."""
        return sum(self.SIGNAL_WEIGHTS.get(k, 0) * v for k, v in signals.items())

class LLMRationaleGenerator:
    """
    Asks the LLM to produce a clear, cited rationale for a recommendation.
    Also generates explicit risk disclosures.
    """

    RATIONALE_PROMPT = """
You are an investment analyst. Given the following signals and portfolio context,
generate a concise investment recommendation rationale.

Rules:
- Cite specific data points (e.g. "3-month momentum: +12%", "analyst consensus: Buy 8/10")
- State the primary thesis in one sentence
- List 3–5 supporting evidence points
- List 2–4 key risks
- Disclose that this is AI-assisted analysis, not financial advice
- Maximum 250 words

Signals: {signals}
Portfolio context: {portfolio_context}
User risk tolerance: {risk_tolerance}
"""

    def __init__(self, router: ModelRouter):
        self.router = router

    def generate(self, ticker: str, signals: dict, score: float,
                 portfolio_context: dict, profile: UserProfile) -> dict:
        """Returns dict with 'rationale', 'risk_factors', 'time_horizon'."""
        raise NotImplementedError

class RecommendationFilter:
    """
    Applies hard constraints to filter out recommendations before they surface.
    """

    def passes(self, ticker: str, rec_type: RecommendationType,
               profile: UserProfile, snapshot: PortfolioSnapshot) -> tuple[bool, str]:
        """
        Returns (ok, reason_if_rejected).
        Checks:
          - Ticker not in restricted_assets
          - Position size within concentration limits
          - Liquidity constraints respected
          - No pattern-day-trade violation (if applicable)
          - Jurisdiction-specific regulatory constraints
        """
        if ticker in profile.restricted_assets:
            return False, f"{ticker} is in restricted assets list"
        # Additional checks...
        return True, ""

class RecommendationEngine:
    """
    Produces a ranked list of actionable recommendations for a user.

    Pipeline:
      1. Generate candidate universe (holdings + watchlist + opportunistic)
      2. Compute signals for each candidate
      3. Filter by hard constraints
      4. Score and rank
      5. LLM generates rationale for top N
      6. Store recommendations in relational DB
      7. Return ranked list
    """

    TOP_N = 5   # max recommendations returned per run

    def __init__(self, signal_aggregator: SignalAggregator,
                 rationale_gen: LLMRationaleGenerator,
                 rec_filter: RecommendationFilter,
                 portfolio_analyzer: PortfolioAnalyzer,
                 relational: RelationalStore,
                 market_data: MarketDataFetcher):
        self.signals    = signal_aggregator
        self.rationale  = rationale_gen
        self.filter     = rec_filter
        self.analyzer   = portfolio_analyzer
        self.relational = relational
        self.market     = market_data

    def run(self, profile: UserProfile) -> list[Recommendation]:
        snapshot  = self.analyzer._load_snapshot(profile.user_id)
        universe  = self._build_universe(profile, snapshot)
        scored    = []

        for ticker in universe:
            signals = self.signals.compute(ticker, self.market, snapshot, profile)
            score   = self.signals.weighted_score(signals)
            rec_type = self._score_to_rec_type(score, ticker, snapshot)
            ok, _   = self.filter.passes(ticker, rec_type, profile, snapshot)
            if ok:
                scored.append((ticker, rec_type, score, signals))

        scored.sort(key=lambda x: abs(x[2]), reverse=True)
        top     = scored[:self.TOP_N]
        results = []
        portfolio_ctx = self.analyzer.current_state(profile.user_id)

        for ticker, rec_type, score, sigs in top:
            rationale_data = self.rationale.generate(
                ticker, sigs, score, portfolio_ctx, profile
            )
            rec = Recommendation(
                rec_id   = str(uuid.uuid4()),
                user_id  = profile.user_id,
                ticker   = ticker,
                rec_type = rec_type,
                rationale      = rationale_data["rationale"],
                confidence     = min(abs(score), 1.0),
                supporting_data= {"signals": sigs, "score": score},
                risk_factors   = rationale_data["risk_factors"],
                time_horizon   = rationale_data["time_horizon"],
                created_at     = datetime.utcnow(),
            )
            self.relational.save_recommendation(profile.user_id, rec)
            results.append(rec)

        return results

    def _build_universe(self, profile: UserProfile,
                         snapshot: PortfolioSnapshot) -> list[str]:
        """
        Candidate pool:
          - Current holdings (always included for SELL/HOLD signals)
          - User watchlist (from relational store)
          - Opportunistic: sector ETFs aligned with user preferences
          - Rebalancing targets if exposure is off-target
        """
        tickers = [h.ticker for h in snapshot.holdings]
        # Add watchlist + opportunistic tickers from relational store
        return list(set(tickers))

    def _score_to_rec_type(self, score: float, ticker: str,
                            snapshot: PortfolioSnapshot) -> RecommendationType:
        holdings = {h.ticker for h in snapshot.holdings}
        if score > 0.3:
            return RecommendationType.BUY
        elif score < -0.3 and ticker in holdings:
            return RecommendationType.SELL
        elif -0.1 <= score <= 0.1 and ticker in holdings:
            return RecommendationType.HOLD
        else:
            return RecommendationType.REBALANCE


# ─────────────────────────────────────────────────────────────────────────────
# 6. PROACTIVE ALERT SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Alert:
    alert_id:   str
    user_id:    str
    severity:   AlertSeverity
    category:   str              # "price" | "risk" | "macro" | "news" | "portfolio"
    title:      str
    body:       str              # LLM-generated natural language explanation
    ticker:     Optional[str]
    data:       dict             # raw data that triggered the alert
    created_at: datetime
    delivered:  bool = False

class AlertRule(ABC):
    """Base class for all alert triggers."""

    @abstractmethod
    def evaluate(self, snapshot: PortfolioSnapshot,
                  market_data: MarketDataFetcher,
                  profile: UserProfile) -> Optional[dict]:
        """
        Returns a dict describing the trigger, or None if condition not met.
        The dict must contain: category, severity, ticker (optional), data.
        """
        ...

class PriceAlertRule(AlertRule):
    """
    Triggers when a holding moves beyond a user-defined or system-default threshold.
    """
    def __init__(self, move_threshold_pct: float = 0.05):
        self.threshold = move_threshold_pct

    def evaluate(self, snapshot, market_data, profile):
        triggered = []
        for h in snapshot.holdings:
            quote   = market_data.get_quote(h.ticker)
            chg_pct = quote.get("change_pct_1d", 0.0)
            if abs(chg_pct) >= self.threshold:
                triggered.append({
                    "category": "price",
                    "severity": AlertSeverity.WARNING if abs(chg_pct) < 0.10
                                else AlertSeverity.CRITICAL,
                    "ticker":   h.ticker,
                    "data":     {"change_pct": chg_pct, "price": quote["price"]},
                })
        return triggered or None

class RiskThresholdAlertRule(AlertRule):
    """Triggers when portfolio VaR breaches user risk tolerance thresholds."""

    THRESHOLDS = {
        RiskTolerance.CONSERVATIVE: 0.02,
        RiskTolerance.MODERATE:     0.04,
        RiskTolerance.AGGRESSIVE:   0.07,
    }

    def __init__(self, risk_engine: RiskEngine):
        self.risk = risk_engine

    def evaluate(self, snapshot, market_data, profile):
        var    = self.risk.var(snapshot, confidence=0.95)
        limit  = self.THRESHOLDS[profile.risk_tolerance] * snapshot.total_value
        if var > limit:
            return [{
                "category": "risk",
                "severity": AlertSeverity.CRITICAL,
                "ticker":   None,
                "data": {"var_1d": var, "limit": limit,
                         "excess_usd": var - limit},
            }]
        return None

class MacroEventAlertRule(AlertRule):
    """
    Triggers on significant macro releases (FOMC, CPI, NFP).
    Checks an economic calendar API and correlates with portfolio exposure.
    """

    def evaluate(self, snapshot, market_data, profile):
        macro = market_data.get_macro_indicators()
        alerts = []
        if macro.get("fed_rate_decision_today"):
            alerts.append({
                "category": "macro",
                "severity": AlertSeverity.INFO,
                "ticker":   None,
                "data":     {"event": "FOMC Decision", "macro": macro},
            })
        return alerts or None

class ConcentrationAlertRule(AlertRule):
    """Fires when a single position exceeds a portfolio weight threshold."""

    def __init__(self, max_single_weight: float = 0.20,
                 exposure_analyzer: ExposureAnalyzer = None):
        self.max_weight = max_single_weight
        self.exposure   = exposure_analyzer or ExposureAnalyzer()

    def evaluate(self, snapshot, market_data, profile):
        alerts = []
        for ticker, weight in snapshot.weights.items():
            if weight > self.max_weight:
                alerts.append({
                    "category": "portfolio",
                    "severity": AlertSeverity.WARNING,
                    "ticker":   ticker,
                    "data":     {"weight": weight, "threshold": self.max_weight},
                })
        return alerts or None

class EarningsAlertRule(AlertRule):
    """Alerts user 48h before an earnings release for a held ticker."""

    def evaluate(self, snapshot, market_data, profile):
        tickers  = [h.ticker for h in snapshot.holdings]
        calendar = market_data.get_earnings_calendar(tickers)
        alerts   = []
        now      = datetime.utcnow()
        for event in calendar:
            release = event.get("datetime")
            if release and (release - now) <= timedelta(hours=48):
                alerts.append({
                    "category": "portfolio",
                    "severity": AlertSeverity.INFO,
                    "ticker":   event["ticker"],
                    "data":     {"earnings_at": str(release),
                                 "consensus_eps": event.get("consensus_eps")},
                })
        return alerts or None

class NewsAlertRule(AlertRule):
    """
    Runs sentiment scoring on breaking news for held tickers.
    High-magnitude negative sentiment triggers an alert.
    """

    NEGATIVE_THRESHOLD = -0.6   # sentiment score in [–1, +1]

    def evaluate(self, snapshot, market_data, profile):
        tickers = [h.ticker for h in snapshot.holdings]
        news    = market_data.get_news(tickers, hours=4)
        alerts  = []
        for item in news:
            if item.get("sentiment", 0) < self.NEGATIVE_THRESHOLD:
                alerts.append({
                    "category": "news",
                    "severity": AlertSeverity.WARNING,
                    "ticker":   item.get("ticker"),
                    "data":     {"headline": item["headline"],
                                 "sentiment": item["sentiment"],
                                 "source": item["source"]},
                })
        return alerts or None

class AlertNarrativeGenerator:
    """
    Turns a raw alert dict into a human-friendly, LLM-generated notification.
    """

    PROMPT = """
You are an investment copilot. Generate a concise, clear alert message.
Category: {category}
Severity: {severity}
Raw data: {data}

Rules:
- One sentence title (< 80 chars)
- 2–3 sentence body explaining what happened, why it matters for the user's portfolio,
  and a suggested first action.
- Do not use jargon without explanation.
- Do not panic the user unnecessarily.
"""

    def __init__(self, router: ModelRouter):
        self.router = router

    def generate(self, raw_alert: dict, profile: UserProfile) -> tuple[str, str]:
        """Returns (title, body)."""
        raise NotImplementedError

class AlertDeduplicator:
    """
    Prevents alert flooding by suppressing near-identical alerts within a TTL window.
    Uses a content hash keyed to (user_id, category, ticker).
    """

    def __init__(self, ttl_seconds: int = 3600):
        self.ttl     = ttl_seconds
        self._seen:  dict[str, float] = {}   # hash → timestamp

    def is_duplicate(self, user_id: str, category: str,
                      ticker: Optional[str], data: dict) -> bool:
        key       = hashlib.sha256(
            f"{user_id}:{category}:{ticker}:{json.dumps(data, sort_keys=True)}"
            .encode()
        ).hexdigest()
        now       = time.time()
        if key in self._seen and now - self._seen[key] < self.ttl:
            return True
        self._seen[key] = now
        return False

class AlertDeliveryBus:
    """
    Delivers alerts to registered channels.
    Channels: WebSocket push, email (SendGrid), SMS (Twilio), webhook.
    """

    def __init__(self, channels: list[Callable[[Alert], None]]):
        self.channels = channels

    def deliver(self, alert: Alert) -> None:
        for channel in self.channels:
            try:
                channel(alert)
                alert.delivered = True
            except Exception as exc:
                # Log delivery failure; retry with exponential backoff
                print(f"Delivery failed via {channel}: {exc}")

class ProactiveAlertSystem:
    """
    Orchestrates the full alert pipeline.

    Run cadence (via scheduler / cron):
      - Price rules:       every 60 seconds
      - Risk rules:        every 5 minutes
      - News rules:        every 10 minutes
      - Macro rules:       every 30 minutes
      - Earnings rules:    every 6 hours

    Pipeline per tick:
      1. Evaluate all rules for each user
      2. Deduplicate
      3. Generate LLM narrative
      4. Persist to DB
      5. Deliver via channels
    """

    def __init__(self, rules: list[AlertRule],
                 narrative_gen: AlertNarrativeGenerator,
                 deduplicator: AlertDeduplicator,
                 delivery_bus: AlertDeliveryBus,
                 portfolio_analyzer: PortfolioAnalyzer,
                 market_data: MarketDataFetcher,
                 relational: RelationalStore):
        self.rules      = rules
        self.narrative  = narrative_gen
        self.dedup      = deduplicator
        self.bus        = delivery_bus
        self.analyzer   = portfolio_analyzer
        self.market     = market_data
        self.relational = relational

    def run_for_user(self, profile: UserProfile) -> list[Alert]:
        snapshot    = self.analyzer._load_snapshot(profile.user_id)
        all_alerts  = []

        for rule in self.rules:
            triggered = rule.evaluate(snapshot, self.market, profile)
            if not triggered:
                continue
            for raw in triggered:
                if self.dedup.is_duplicate(
                    profile.user_id, raw["category"],
                    raw.get("ticker"), raw["data"]
                ):
                    continue
                title, body = self.narrative.generate(raw, profile)
                alert = Alert(
                    alert_id   = str(uuid.uuid4()),
                    user_id    = profile.user_id,
                    severity   = raw["severity"],
                    category   = raw["category"],
                    title      = title,
                    body       = body,
                    ticker     = raw.get("ticker"),
                    data       = raw["data"],
                    created_at = datetime.utcnow(),
                )
                self.bus.deliver(alert)
                all_alerts.append(alert)

        return all_alerts

    def run_for_all_users(self, profiles: list[UserProfile]) -> dict[str, list[Alert]]:
        """Called by the scheduler. Returns alerts keyed by user_id."""
        return {p.user_id: self.run_for_user(p) for p in profiles}


# ─────────────────────────────────────────────────────────────────────────────
# DEPENDENCY WIRING — COMPOSITION ROOT
# ─────────────────────────────────────────────────────────────────────────────

def build_investment_copilot(
    api_keys: dict[ModelProvider, str],
    vector_store: VectorStore,
    relational_store: RelationalStore,
    delivery_channels: list[Callable[[Alert], None]],
) -> dict[str, Any]:
    """
    Wires all modules together and returns the fully-assembled copilot components.
    In production, replace with a DI container (e.g. dependency-injector).
    """

    # Infrastructure
    router        = ModelRouter(api_keys)
    embed_svc     = EmbeddingService(ModelProvider.OPENAI,
                                      api_keys[ModelProvider.OPENAI])
    market_data   = MarketDataFetcher()

    # Memory
    short_mem     = ShortTermMemory()
    long_mem      = LongTermMemory(vector_store, relational_store, embed_svc, router)
    memory        = MemorySystem(short_mem, long_mem)

    # Portfolio
    risk_engine   = RiskEngine()
    exposure      = ExposureAnalyzer()
    tax           = TaxAnalyzer()
    portfolio     = PortfolioAnalyzer(relational_store, market_data,
                                       risk_engine, exposure, tax)

    # Context injection
    injector      = ContextInjector(memory, market_data, portfolio, relational_store)

    # Reasoning
    orchestrator  = ChainOfThoughtOrchestrator(router, memory, injector)
    ai_system     = AIReasoningSystem(router, orchestrator, memory, injector)

    # Recommendations
    signals       = SignalAggregator()
    rationale_gen = LLMRationaleGenerator(router)
    rec_filter    = RecommendationFilter()
    rec_engine    = RecommendationEngine(signals, rationale_gen, rec_filter,
                                          portfolio, relational_store, market_data)

    # Alerts
    alert_rules = [
        PriceAlertRule(move_threshold_pct=0.05),
        RiskThresholdAlertRule(risk_engine),
        MacroEventAlertRule(),
        ConcentrationAlertRule(max_single_weight=0.20, exposure_analyzer=exposure),
        EarningsAlertRule(),
        NewsAlertRule(),
    ]
    narrative_gen  = AlertNarrativeGenerator(router)
    deduplicator   = AlertDeduplicator(ttl_seconds=3600)
    delivery_bus   = AlertDeliveryBus(delivery_channels)
    alert_system   = ProactiveAlertSystem(
        alert_rules, narrative_gen, deduplicator, delivery_bus,
        portfolio, market_data, relational_store,
    )

    return {
        "ai":          ai_system,
        "memory":      memory,
        "portfolio":   portfolio,
        "recommender": rec_engine,
        "alerts":      alert_system,
        "injector":    injector,
    }
